package com.example.domain

import android.content.Context
import android.util.Log
import com.example.alarm.AlarmAudioManager
import com.example.alarm.NotificationHelper
import com.example.data.db.AlertHistoryEntity
import com.example.data.db.AlertRepository
import com.example.data.db.AlertRuleEntity
import com.example.data.model.FluctuationType
import com.example.data.model.RollingPricePoint
import com.example.data.model.Ticker24h
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

class FluctuationEngine(
    private val context: Context,
    private val repository: AlertRepository
) {
    private val tag = "FluctuationEngine"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    // In-memory sliding price history per symbol: symbol -> List of RollingPricePoint
    private val priceHistoryMap = ConcurrentHashMap<String, MutableList<RollingPricePoint>>()

    // Global Sentinel configuration
    var isGlobalSentinelEnabled: Boolean = true
    var globalThresholdPercent: Double = 2.0 // Trigger if ANY major coin fluctuates > 2.0%
    var globalWindowMinutes: Int = 3
    private var lastGlobalAlertTime: Long = 0

    private val _lastDetectedSpike = MutableStateFlow<AlertHistoryEntity?>(null)
    val lastDetectedSpike: StateFlow<AlertHistoryEntity?> = _lastDetectedSpike.asStateFlow()

    fun processPriceUpdate(ticker: Ticker24h) {
        val sym = ticker.symbol.uppercase()
        val price = ticker.lastPrice
        val now = System.currentTimeMillis()

        if (price <= 0) return

        // 1. Record point into rolling history
        val list = priceHistoryMap.computeIfAbsent(sym) { mutableListOf() }
        synchronized(list) {
            list.add(RollingPricePoint(price, now))
            // Prune points older than 20 minutes
            val cutoff = now - 20 * 60 * 1000
            list.removeAll { it.timestamp < cutoff }
        }

        // 2. Check Custom Alert Rules
        scope.launch {
            checkRulesForSymbol(sym, price, now, ticker)
        }

        // 3. Check Global Sentinel
        if (isGlobalSentinelEnabled) {
            checkGlobalSentinel(sym, price, now)
        }
    }

    private suspend fun checkRulesForSymbol(
        symbol: String,
        currentPrice: Double,
        now: Long,
        ticker: Ticker24h
    ) {
        val rules = repository.getActiveRulesList().filter { it.symbol.equals(symbol, ignoreCase = true) }
        val priceHistory = synchronized(priceHistoryMap.computeIfAbsent(symbol) { mutableListOf() }) {
            priceHistoryMap[symbol]?.toList() ?: emptyList()
        }

        for (rule in rules) {
            // Check cooldown
            if (now - rule.lastTriggeredAt < rule.cooldownSeconds * 1000) {
                continue
            }

            var isTriggered = false
            var triggerTitle = ""
            var triggerMessage = ""
            var priceBefore = rule.basePriceAtCreation.takeIf { it > 0 } ?: currentPrice
            var changePct = 0.0

            when (rule.fluctuationType) {
                FluctuationType.PRICE_ABOVE -> {
                    if (currentPrice >= rule.targetValue) {
                        isTriggered = true
                        changePct = if (priceBefore > 0) ((currentPrice - priceBefore) / priceBefore) * 100 else 0.0
                        triggerTitle = "🚀 TARGET NAIK TERCAPAI"
                        triggerMessage = "$symbol menembus di atas target $${rule.targetValue} (Harga saat ini: $$currentPrice)"
                    }
                }
                FluctuationType.PRICE_BELOW -> {
                    if (currentPrice <= rule.targetValue) {
                        isTriggered = true
                        changePct = if (priceBefore > 0) ((currentPrice - priceBefore) / priceBefore) * 100 else 0.0
                        triggerTitle = "🔻 TARGET TURUN TERCAPAI"
                        triggerMessage = "$symbol turun di bawah target $${rule.targetValue} (Harga saat ini: $$currentPrice)"
                    }
                }
                FluctuationType.SPIKE_UP -> {
                    val windowStart = now - (rule.timeframeMinutes * 60 * 1000)
                    val windowPoints = priceHistory.filter { it.timestamp >= windowStart }
                    if (windowPoints.isNotEmpty()) {
                        val minPrice = windowPoints.minOf { it.price }
                        if (minPrice > 0) {
                            val spike = ((currentPrice - minPrice) / minPrice) * 100
                            if (spike >= rule.targetValue) {
                                isTriggered = true
                                priceBefore = minPrice
                                changePct = spike
                                triggerTitle = "⚡ LONJAKAN HARGA CEPAT (SPIKE)"
                                triggerMessage = "$symbol melonjak +${String.format("%.2f", spike)}% dalam ${rule.timeframeMinutes} menit! ($$minPrice -> $$currentPrice)"
                            }
                        }
                    }
                }
                FluctuationType.DUMP_DOWN -> {
                    val windowStart = now - (rule.timeframeMinutes * 60 * 1000)
                    val windowPoints = priceHistory.filter { it.timestamp >= windowStart }
                    if (windowPoints.isNotEmpty()) {
                        val maxPrice = windowPoints.maxOf { it.price }
                        if (maxPrice > 0) {
                            val dump = ((maxPrice - currentPrice) / maxPrice) * 100
                            if (dump >= rule.targetValue) {
                                isTriggered = true
                                priceBefore = maxPrice
                                changePct = -dump
                                triggerTitle = "⚠️ PENURUNAN TAJAM (FLASH DUMP)"
                                triggerMessage = "$symbol anjlok -${String.format("%.2f", dump)}% dalam ${rule.timeframeMinutes} menit! ($$maxPrice -> $$currentPrice)"
                            }
                        }
                    }
                }
                FluctuationType.ANY_VOLATILITY -> {
                    val windowStart = now - (rule.timeframeMinutes * 60 * 1000)
                    val windowPoints = priceHistory.filter { it.timestamp >= windowStart }
                    if (windowPoints.isNotEmpty()) {
                        val oldestPrice = windowPoints.first().price
                        if (oldestPrice > 0) {
                            val diff = ((currentPrice - oldestPrice) / oldestPrice) * 100
                            if (kotlin.math.abs(diff) >= rule.targetValue) {
                                isTriggered = true
                                priceBefore = oldestPrice
                                changePct = diff
                                val sign = if (diff >= 0) "+" else ""
                                triggerTitle = "🔥 FLUKTUASI BESAR TERDETEKSI"
                                triggerMessage = "$symbol bergerak $sign${String.format("%.2f", diff)}% dalam ${rule.timeframeMinutes} menit ($$oldestPrice -> $$currentPrice)"
                            }
                        }
                    }
                }
            }

            if (isTriggered) {
                fireAlert(
                    ruleId = rule.id,
                    symbol = symbol,
                    title = triggerTitle,
                    message = triggerMessage,
                    ruleType = rule.ruleType,
                    priceBefore = priceBefore,
                    priceTriggered = currentPrice,
                    changePercent = changePct,
                    triggerAlarmSound = rule.triggerAlarmSound,
                    triggerVibration = rule.triggerVibration,
                    isOneShot = rule.isOneShot
                )
            }
        }
    }

    private fun checkGlobalSentinel(symbol: String, currentPrice: Double, now: Long) {
        // Minimum 90 seconds between global sentinel alarms to prevent overwhelm
        if (now - lastGlobalAlertTime < 90 * 1000) return

        val priceHistory = synchronized(priceHistoryMap.computeIfAbsent(symbol) { mutableListOf() }) {
            priceHistoryMap[symbol]?.toList() ?: emptyList()
        }

        val windowStart = now - (globalWindowMinutes * 60 * 1000)
        val windowPoints = priceHistory.filter { it.timestamp >= windowStart }
        if (windowPoints.size >= 2) {
            val oldest = windowPoints.first().price
            if (oldest > 0) {
                val pct = ((currentPrice - oldest) / oldest) * 100
                if (kotlin.math.abs(pct) >= globalThresholdPercent) {
                    lastGlobalAlertTime = now
                    val isSpike = pct > 0
                    val sign = if (isSpike) "+" else ""
                    val title = if (isSpike) "⚡ GLOBAL SENTINEL: SPIKE $symbol" else "🚨 GLOBAL SENTINEL: DUMP $symbol"
                    val msg = "$symbol bergerak drastis $sign${String.format("%.2f", pct)}% dalam $globalWindowMinutes menit! ($$oldest -> $$currentPrice)"

                    scope.launch {
                        fireAlert(
                            ruleId = 0,
                            symbol = symbol,
                            title = title,
                            message = msg,
                            ruleType = if (isSpike) FluctuationType.SPIKE_UP.name else FluctuationType.DUMP_DOWN.name,
                            priceBefore = oldest,
                            priceTriggered = currentPrice,
                            changePercent = pct,
                            triggerAlarmSound = true,
                            triggerVibration = true,
                            isOneShot = false
                        )
                    }
                }
            }
        }
    }

    private suspend fun fireAlert(
        ruleId: Long,
        symbol: String,
        title: String,
        message: String,
        ruleType: String,
        priceBefore: Double,
        priceTriggered: Double,
        changePercent: Double,
        triggerAlarmSound: Boolean,
        triggerVibration: Boolean,
        isOneShot: Boolean
    ) {
        Log.w(tag, "ALARM FIRED: $title - $message")

        // 1. Update rule state in DB
        val now = System.currentTimeMillis()
        if (ruleId > 0) {
            repository.updateLastTriggered(ruleId, now)
            if (isOneShot) {
                repository.setRuleEnabled(ruleId, false)
            }
        }

        // 2. Record to history
        val historyId = repository.recordAlertTriggered(
            ruleId = ruleId,
            symbol = symbol,
            title = title,
            message = message,
            ruleType = ruleType,
            priceBefore = priceBefore,
            priceTriggered = priceTriggered,
            changePercent = changePercent
        )

        val historyItem = AlertHistoryEntity(
            id = historyId,
            ruleId = ruleId,
            symbol = symbol,
            title = title,
            message = message,
            ruleType = ruleType,
            priceBefore = priceBefore,
            priceTriggered = priceTriggered,
            changePercent = changePercent,
            timestamp = now,
            isAlarmTriggered = true
        )

        _lastDetectedSpike.value = historyItem

        // 3. Trigger Phone Alarm & Vibration
        if (triggerAlarmSound || triggerVibration) {
            AlarmAudioManager.triggerAlarm(
                context = context,
                alertInfo = historyItem,
                soundType = AlarmAudioManager.selectedSoundType,
                enableVibration = triggerVibration
            )
        }

        // 4. Show Heads-Up Notification
        NotificationHelper.showPriceAlarmNotification(context, historyItem)
    }

    fun getRecentFluctuationForSymbol(symbol: String, minutes: Int = 5): Double {
        val list = synchronized(priceHistoryMap.computeIfAbsent(symbol.uppercase()) { mutableListOf() }) {
            priceHistoryMap[symbol.uppercase()]?.toList() ?: emptyList()
        }
        if (list.size < 2) return 0.0
        val cutoff = System.currentTimeMillis() - minutes * 60 * 1000
        val points = list.filter { it.timestamp >= cutoff }
        if (points.size < 2) return 0.0
        val oldest = points.first().price
        val newest = points.last().price
        return if (oldest > 0) ((newest - oldest) / oldest) * 100 else 0.0
    }
}

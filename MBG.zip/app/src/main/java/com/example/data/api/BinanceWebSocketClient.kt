package com.example.data.api

import android.util.Log
import com.example.data.model.CandleData
import com.example.data.model.MarketConnectionStatus
import com.example.data.model.RecentTrade
import com.example.data.model.Ticker24h
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class BinanceWebSocketClient(
    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()
) {
    private val tag = "BinanceWebSocket"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // Fallback endpoints for Binance WebSocket streams
    private val wsEndpoints = listOf(
        "wss://data-stream.binance.vision/stream",
        "wss://data-stream.binance.vision:9443/stream",
        "wss://stream.binance.com:9443/stream",
        "wss://stream.binance.com:443/stream",
        "wss://stream.binance.us:9443/stream"
    )
    private var activeEndpointIndex = 0

    private var activeWebSocket: WebSocket? = null
    private var currentSymbol: String = "BTCUSDT"
    private val isConnecting = AtomicBoolean(false)
    private var reconnectJob: Job? = null

    private val _connectionStatus = MutableStateFlow(MarketConnectionStatus.DISCONNECTED)
    val connectionStatus: StateFlow<MarketConnectionStatus> = _connectionStatus.asStateFlow()

    private val _liveTicker = MutableSharedFlow<Ticker24h>(extraBufferCapacity = 64)
    val liveTicker: SharedFlow<Ticker24h> = _liveTicker.asSharedFlow()

    private val _liveTrade = MutableSharedFlow<RecentTrade>(extraBufferCapacity = 64)
    val liveTrade: SharedFlow<RecentTrade> = _liveTrade.asSharedFlow()

    private val _liveCandle = MutableSharedFlow<CandleData>(extraBufferCapacity = 64)
    val liveCandle: SharedFlow<CandleData> = _liveCandle.asSharedFlow()

    private val _allMiniTickers = MutableSharedFlow<List<Ticker24h>>(extraBufferCapacity = 16)
    val allMiniTickers: SharedFlow<List<Ticker24h>> = _allMiniTickers.asSharedFlow()

    fun connect(symbol: String) {
        currentSymbol = symbol.uppercase()
        reconnectJob?.cancel()
        disconnectInternal()
        startConnection()
    }

    private fun startConnection() {
        if (isConnecting.getAndSet(true)) return

        _connectionStatus.value = if (activeEndpointIndex == 0) MarketConnectionStatus.CONNECTING else MarketConnectionStatus.RECONNECTING
        val sym = currentSymbol.lowercase()

        val baseUrl = wsEndpoints[activeEndpointIndex % wsEndpoints.size]
        val streamUrl = "$baseUrl?streams=${sym}@ticker/${sym}@trade/${sym}@kline_1m/!miniTicker@arr"

        Log.d(tag, "Connecting to WebSocket endpoint: $baseUrl for $currentSymbol")

        val request = Request.Builder()
            .url(streamUrl)
            .header("User-Agent", "Mozilla/5.0 (Android; Mobile)")
            .build()

        activeWebSocket = okHttpClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                isConnecting.set(false)
                _connectionStatus.value = MarketConnectionStatus.CONNECTED
                Log.d(tag, "WebSocket connected successfully to Binance ($baseUrl) for $currentSymbol")
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                scope.launch {
                    try {
                        parseStreamMessage(text)
                    } catch (e: Exception) {
                        Log.e(tag, "Error parsing WS message", e)
                    }
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                isConnecting.set(false)
                val responseCode = response?.code
                Log.w(tag, "WebSocket failure from $baseUrl: ${t.message} (HTTP $responseCode)")

                // Switch to next fallback endpoint and attempt failover reconnect
                activeEndpointIndex = (activeEndpointIndex + 1) % wsEndpoints.size
                _connectionStatus.value = MarketConnectionStatus.RECONNECTING

                reconnectJob?.cancel()
                reconnectJob = scope.launch {
                    delay(1200)
                    startConnection()
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                isConnecting.set(false)
                _connectionStatus.value = MarketConnectionStatus.DISCONNECTED
                Log.d(tag, "WebSocket closed: $reason")
            }
        })
    }

    private fun parseStreamMessage(jsonString: String) {
        val root = JSONObject(jsonString)
        val stream = root.optString("stream", "")
        val data = root.optJSONObject("data") ?: root.optJSONArray("data")

        when {
            // Ticker Stream (e.g. btcusdt@ticker)
            stream.contains("@ticker") && data is JSONObject -> {
                val sym = data.optString("s", "")
                val lastPrice = data.optString("c", "0").toDoubleOrNull() ?: 0.0
                val priceChange = data.optString("p", "0").toDoubleOrNull() ?: 0.0
                val priceChangePercent = data.optString("P", "0").toDoubleOrNull() ?: 0.0
                val highPrice = data.optString("h", "0").toDoubleOrNull() ?: 0.0
                val lowPrice = data.optString("l", "0").toDoubleOrNull() ?: 0.0
                val volume = data.optString("v", "0").toDoubleOrNull() ?: 0.0
                val quoteVolume = data.optString("q", "0").toDoubleOrNull() ?: 0.0
                val openPrice = data.optString("o", "0").toDoubleOrNull() ?: 0.0

                val ticker = Ticker24h(
                    symbol = sym,
                    lastPrice = lastPrice,
                    priceChange = priceChange,
                    priceChangePercent = priceChangePercent,
                    highPrice = highPrice,
                    lowPrice = lowPrice,
                    volume = volume,
                    quoteVolume = quoteVolume,
                    openPrice = openPrice,
                    lastUpdated = System.currentTimeMillis()
                )
                _liveTicker.tryEmit(ticker)
            }

            // Trade Stream (e.g. btcusdt@trade)
            stream.contains("@trade") && data is JSONObject -> {
                val trade = RecentTrade(
                    id = data.optLong("t", 0),
                    price = data.optString("p", "0").toDoubleOrNull() ?: 0.0,
                    qty = data.optString("q", "0").toDoubleOrNull() ?: 0.0,
                    time = data.optLong("T", System.currentTimeMillis()),
                    isBuyerMaker = data.optBoolean("m", false)
                )
                _liveTrade.tryEmit(trade)
            }

            // Kline Candlestick Stream (e.g. btcusdt@kline_1m)
            stream.contains("@kline") && data is JSONObject -> {
                val k = data.optJSONObject("k")
                if (k != null) {
                    val candle = CandleData(
                        openTime = k.optLong("t", 0),
                        open = k.optString("o", "0").toDoubleOrNull() ?: 0.0,
                        high = k.optString("h", "0").toDoubleOrNull() ?: 0.0,
                        low = k.optString("l", "0").toDoubleOrNull() ?: 0.0,
                        close = k.optString("c", "0").toDoubleOrNull() ?: 0.0,
                        volume = k.optString("v", "0").toDoubleOrNull() ?: 0.0,
                        closeTime = k.optLong("T", 0)
                    )
                    _liveCandle.tryEmit(candle)
                }
            }

            // All mini tickers (e.g. !miniTicker@arr)
            stream.contains("!miniTicker") && data is JSONArray -> {
                val list = mutableListOf<Ticker24h>()
                for (i in 0 until data.length()) {
                    val item = data.getJSONObject(i)
                    val sym = item.optString("s", "")
                    if (sym.endsWith("USDT")) {
                        val close = item.optString("c", "0").toDoubleOrNull() ?: 0.0
                        val open = item.optString("o", "0").toDoubleOrNull() ?: 0.0
                        val high = item.optString("h", "0").toDoubleOrNull() ?: 0.0
                        val low = item.optString("l", "0").toDoubleOrNull() ?: 0.0
                        val vol = item.optString("v", "0").toDoubleOrNull() ?: 0.0
                        val qVol = item.optString("q", "0").toDoubleOrNull() ?: 0.0
                        val pct = if (open > 0) ((close - open) / open) * 100 else 0.0

                        list.add(
                            Ticker24h(
                                symbol = sym,
                                lastPrice = close,
                                priceChange = close - open,
                                priceChangePercent = pct,
                                highPrice = high,
                                lowPrice = low,
                                volume = vol,
                                quoteVolume = qVol,
                                openPrice = open,
                                lastUpdated = System.currentTimeMillis()
                            )
                        )
                    }
                }
                if (list.isNotEmpty()) {
                    _allMiniTickers.tryEmit(list)
                }
            }
        }
    }

    private fun disconnectInternal() {
        try {
            activeWebSocket?.close(1000, "Switching or reconnecting")
        } catch (e: Exception) {
            Log.e(tag, "Error closing websocket", e)
        }
        activeWebSocket = null
        isConnecting.set(false)
    }

    fun disconnect() {
        reconnectJob?.cancel()
        disconnectInternal()
        _connectionStatus.value = MarketConnectionStatus.DISCONNECTED
    }
}

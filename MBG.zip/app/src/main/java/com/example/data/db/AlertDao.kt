package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AlertDao {

    @Query("SELECT * FROM alert_rules ORDER BY id DESC")
    fun getAllRules(): Flow<List<AlertRuleEntity>>

    @Query("SELECT * FROM alert_rules WHERE isEnabled = 1")
    fun getActiveRulesFlow(): Flow<List<AlertRuleEntity>>

    @Query("SELECT * FROM alert_rules WHERE isEnabled = 1")
    suspend fun getActiveRulesList(): List<AlertRuleEntity>

    @Query("SELECT * FROM alert_rules WHERE id = :id")
    suspend fun getRuleById(id: Long): AlertRuleEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRule(rule: AlertRuleEntity): Long

    @Update
    suspend fun updateRule(rule: AlertRuleEntity)

    @Delete
    suspend fun deleteRule(rule: AlertRuleEntity)

    @Query("DELETE FROM alert_rules WHERE id = :id")
    suspend fun deleteRuleById(id: Long)

    @Query("UPDATE alert_rules SET isEnabled = :isEnabled WHERE id = :id")
    suspend fun setRuleEnabled(id: Long, isEnabled: Boolean)

    @Query("UPDATE alert_rules SET lastTriggeredAt = :timestamp WHERE id = :id")
    suspend fun updateLastTriggered(id: Long, timestamp: Long)

    // History
    @Query("SELECT * FROM alert_history ORDER BY timestamp DESC LIMIT 200")
    fun getAllHistory(): Flow<List<AlertHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: AlertHistoryEntity): Long

    @Query("DELETE FROM alert_history")
    suspend fun clearAllHistory()

    @Query("DELETE FROM alert_history WHERE id = :id")
    suspend fun deleteHistoryById(id: Long)
}

package com.example.data.api

import android.util.Log
import com.example.data.model.CandleData
import com.example.data.model.OrderBookData
import com.example.data.model.OrderBookEntry
import com.example.data.model.RecentTrade
import com.example.data.model.Ticker24h
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class BinanceApiService(
    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()
) {
    private val tag = "BinanceApiService"

    private val baseUrls = listOf(
        "https://data-api.binance.vision/api/v3",
        "https://api.binance.com/api/v3",
        "https://api1.binance.com/api/v3",
        "https://api2.binance.com/api/v3",
        "https://api3.binance.com/api/v3",
        "https://api.binance.us/api/v3"
    )

    private var activeBaseUrlIndex = 0

    private fun executeWithFallback(pathAndQuery: String): Result<String> {
        var lastException: Exception? = null
        val startIndex = activeBaseUrlIndex

        for (offset in baseUrls.indices) {
            val index = (startIndex + offset) % baseUrls.size
            val baseUrl = baseUrls[index]
            val url = "$baseUrl$pathAndQuery"

            try {
                val request = Request.Builder()
                    .url(url)
                    .header("User-Agent", "Mozilla/5.0 (Android; Mobile)")
                    .header("Accept", "application/json")
                    .build()

                val response: Response = okHttpClient.newCall(request).execute()
                if (response.isSuccessful) {
                    val bodyString = response.body?.string() ?: ""
                    activeBaseUrlIndex = index // Remember successful baseUrl
                    return Result.success(bodyString)
                } else {
                    val code = response.code
                    Log.w(tag, "HTTP $code from $url, trying next endpoint...")
                    lastException = Exception("HTTP $code: ${response.message}")
                    // If 451, 403, or 5xx, continue to next baseUrl in list
                }
            } catch (e: Exception) {
                Log.w(tag, "Failed to connect to $url: ${e.message}, trying next endpoint...")
                lastException = e
            }
        }
        return Result.failure(lastException ?: Exception("All endpoints failed"))
    }

    suspend fun getKlines(
        symbol: String,
        interval: String = "15m",
        limit: Int = 100
    ): Result<List<CandleData>> = withContext(Dispatchers.IO) {
        try {
            val path = "/klines?symbol=${symbol.uppercase()}&interval=$interval&limit=$limit"
            val bodyResult = executeWithFallback(path)
            if (bodyResult.isFailure) {
                return@withContext Result.failure(bodyResult.exceptionOrNull() ?: Exception("Unknown error"))
            }

            val bodyString = bodyResult.getOrThrow()
            val jsonArray = JSONArray(bodyString)
            val candles = mutableListOf<CandleData>()

            for (i in 0 until jsonArray.length()) {
                val item = jsonArray.getJSONArray(i)
                val candle = CandleData(
                    openTime = item.getLong(0),
                    open = item.getString(1).toDoubleOrNull() ?: 0.0,
                    high = item.getString(2).toDoubleOrNull() ?: 0.0,
                    low = item.getString(3).toDoubleOrNull() ?: 0.0,
                    close = item.getString(4).toDoubleOrNull() ?: 0.0,
                    volume = item.getString(5).toDoubleOrNull() ?: 0.0,
                    closeTime = item.getLong(6)
                )
                candles.add(candle)
            }
            Result.success(candles)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getTicker24h(symbol: String): Result<Ticker24h> = withContext(Dispatchers.IO) {
        try {
            val path = "/ticker/24hr?symbol=${symbol.uppercase()}"
            val bodyResult = executeWithFallback(path)
            if (bodyResult.isFailure) {
                return@withContext Result.failure(bodyResult.exceptionOrNull() ?: Exception("Unknown error"))
            }

            val json = JSONObject(bodyResult.getOrThrow())
            val ticker = parseTicker(json)
            Result.success(ticker)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getTopTickers24h(): Result<List<Ticker24h>> = withContext(Dispatchers.IO) {
        try {
            val path = "/ticker/24hr"
            val bodyResult = executeWithFallback(path)
            if (bodyResult.isFailure) {
                return@withContext Result.failure(bodyResult.exceptionOrNull() ?: Exception("Unknown error"))
            }

            val array = JSONArray(bodyResult.getOrThrow())
            val list = mutableListOf<Ticker24h>()

            val popularSymbols = setOf(
                "BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT", "XRPUSDT",
                "DOGEUSDT", "ADAUSDT", "AVAXUSDT", "SUIUSDT", "LINKUSDT",
                "NEARUSDT", "PEPEUSDT", "SHIBUSDT", "TRXUSDT", "DOTUSDT",
                "LTCUSDT", "APTUSDT", "MATICUSDT", "RENDERUSDT", "FETUSDT",
                "TAOUSDT", "WIFUSDT", "INJUSDT", "ATOMUSDT", "FTMUSDT"
            )

            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                val sym = item.optString("symbol", "")
                if (popularSymbols.contains(sym) || (sym.endsWith("USDT") && sym.length <= 9)) {
                    list.add(parseTicker(item))
                }
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getOrderBook(symbol: String, limit: Int = 20): Result<OrderBookData> = withContext(Dispatchers.IO) {
        try {
            val path = "/depth?symbol=${symbol.uppercase()}&limit=$limit"
            val bodyResult = executeWithFallback(path)
            if (bodyResult.isFailure) {
                return@withContext Result.failure(bodyResult.exceptionOrNull() ?: Exception("Unknown error"))
            }

            val json = JSONObject(bodyResult.getOrThrow())
            val bidsArray = json.optJSONArray("bids") ?: JSONArray()
            val asksArray = json.optJSONArray("asks") ?: JSONArray()

            val bids = mutableListOf<OrderBookEntry>()
            for (i in 0 until bidsArray.length()) {
                val entry = bidsArray.getJSONArray(i)
                val p = entry.getString(0).toDoubleOrNull() ?: 0.0
                val q = entry.getString(1).toDoubleOrNull() ?: 0.0
                bids.add(OrderBookEntry(p, q))
            }

            val asks = mutableListOf<OrderBookEntry>()
            for (i in 0 until asksArray.length()) {
                val entry = asksArray.getJSONArray(i)
                val p = entry.getString(0).toDoubleOrNull() ?: 0.0
                val q = entry.getString(1).toDoubleOrNull() ?: 0.0
                asks.add(OrderBookEntry(p, q))
            }

            Result.success(OrderBookData(bids = bids, asks = asks))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getRecentTrades(symbol: String, limit: Int = 30): Result<List<RecentTrade>> = withContext(Dispatchers.IO) {
        try {
            val path = "/trades?symbol=${symbol.uppercase()}&limit=$limit"
            val bodyResult = executeWithFallback(path)
            if (bodyResult.isFailure) {
                return@withContext Result.failure(bodyResult.exceptionOrNull() ?: Exception("Unknown error"))
            }

            val array = JSONArray(bodyResult.getOrThrow())
            val list = mutableListOf<RecentTrade>()

            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    RecentTrade(
                        id = obj.optLong("id", 0),
                        price = obj.optString("price", "0").toDoubleOrNull() ?: 0.0,
                        qty = obj.optString("qty", "0").toDoubleOrNull() ?: 0.0,
                        time = obj.optLong("time", 0),
                        isBuyerMaker = obj.optBoolean("isBuyerMaker", false)
                    )
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun parseTicker(json: JSONObject): Ticker24h {
        val sym = json.optString("symbol", "")
        val lastPrice = json.optString("lastPrice", "0").toDoubleOrNull() ?: 0.0
        val priceChange = json.optString("priceChange", "0").toDoubleOrNull() ?: 0.0
        val priceChangePercent = json.optString("priceChangePercent", "0").toDoubleOrNull() ?: 0.0
        val highPrice = json.optString("highPrice", "0").toDoubleOrNull() ?: 0.0
        val lowPrice = json.optString("lowPrice", "0").toDoubleOrNull() ?: 0.0
        val volume = json.optString("volume", "0").toDoubleOrNull() ?: 0.0
        val quoteVolume = json.optString("quoteVolume", "0").toDoubleOrNull() ?: 0.0
        val openPrice = json.optString("openPrice", "0").toDoubleOrNull() ?: 0.0

        return Ticker24h(
            symbol = sym,
            lastPrice = lastPrice,
            priceChange = priceChange,
            priceChangePercent = priceChangePercent,
            highPrice = highPrice,
            lowPrice = lowPrice,
            volume = volume,
            quoteVolume = quoteVolume,
            openPrice = openPrice,
            lastUpdated = System.currentTimeMillis()
        )
    }
}

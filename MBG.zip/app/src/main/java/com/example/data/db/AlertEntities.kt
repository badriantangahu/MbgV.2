package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.FluctuationType

@Entity(tableName = "alert_rules")
data class AlertRuleEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val symbol: String,
    val ruleType: String, // from FluctuationType.name
    val targetValue: Double, // target price or percentage value (e.g. 2.5 for 2.5%)
    val timeframeMinutes: Int = 3, // for velocity/spike/dump detection
    val basePriceAtCreation: Double = 0.0,
    val isEnabled: Boolean = true,
    val triggerAlarmSound: Boolean = true,
    val triggerVibration: Boolean = true,
    val isOneShot: Boolean = false,
    val cooldownSeconds: Long = 120, // min interval between repeating alarms for this rule
    val lastTriggeredAt: Long = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val notes: String = ""
) {
    val fluctuationType: FluctuationType
        get() = try {
            FluctuationType.valueOf(ruleType)
        } catch (e: Exception) {
            FluctuationType.ANY_VOLATILITY
        }
}

@Entity(tableName = "alert_history")
data class AlertHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val ruleId: Long = 0,
    val symbol: String,
    val title: String,
    val message: String,
    val ruleType: String,
    val priceBefore: Double,
    val priceTriggered: Double,
    val changePercent: Double,
    val timestamp: Long = System.currentTimeMillis(),
    val isAlarmTriggered: Boolean = true
)

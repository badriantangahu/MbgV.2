package com.example.data.db

import kotlinx.coroutines.flow.Flow

class AlertRepository(private val alertDao: AlertDao) {

    val allRules: Flow<List<AlertRuleEntity>> = alertDao.getAllRules()
    val activeRules: Flow<List<AlertRuleEntity>> = alertDao.getActiveRulesFlow()
    val history: Flow<List<AlertHistoryEntity>> = alertDao.getAllHistory()

    suspend fun getActiveRulesList(): List<AlertRuleEntity> = alertDao.getActiveRulesList()

    suspend fun insertRule(rule: AlertRuleEntity): Long = alertDao.insertRule(rule)

    suspend fun updateRule(rule: AlertRuleEntity) = alertDao.updateRule(rule)

    suspend fun deleteRule(rule: AlertRuleEntity) = alertDao.deleteRule(rule)

    suspend fun deleteRuleById(id: Long) = alertDao.deleteRuleById(id)

    suspend fun setRuleEnabled(id: Long, isEnabled: Boolean) = alertDao.setRuleEnabled(id, isEnabled)

    suspend fun updateLastTriggered(id: Long, timestamp: Long) = alertDao.updateLastTriggered(id, timestamp)

    suspend fun recordAlertTriggered(
        ruleId: Long,
        symbol: String,
        title: String,
        message: String,
        ruleType: String,
        priceBefore: Double,
        priceTriggered: Double,
        changePercent: Double
    ): Long {
        val history = AlertHistoryEntity(
            ruleId = ruleId,
            symbol = symbol,
            title = title,
            message = message,
            ruleType = ruleType,
            priceBefore = priceBefore,
            priceTriggered = priceTriggered,
            changePercent = changePercent,
            timestamp = System.currentTimeMillis(),
            isAlarmTriggered = true
        )
        return alertDao.insertHistory(history)
    }

    suspend fun clearHistory() = alertDao.clearAllHistory()

    suspend fun deleteHistoryItem(id: Long) = alertDao.deleteHistoryById(id)
}

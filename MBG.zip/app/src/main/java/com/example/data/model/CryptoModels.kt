package com.example.data.model

data class CandleData(
    val openTime: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double,
    val closeTime: Long
) {
    val isBullish: Boolean get() = close >= open
    val bodyTop: Double get() = maxOf(open, close)
    val bodyBottom: Double get() = minOf(open, close)
}

data class Ticker24h(
    val symbol: String,
    val lastPrice: Double,
    val priceChange: Double,
    val priceChangePercent: Double,
    val highPrice: Double,
    val lowPrice: Double,
    val volume: Double,
    val quoteVolume: Double,
    val openPrice: Double = 0.0,
    val lastUpdated: Long = System.currentTimeMillis()
) {
    val isPositive: Boolean get() = priceChangePercent >= 0
    val formattedSymbol: String get() = symbol.replace("USDT", "/USDT")
    val baseAsset: String get() = symbol.removeSuffix("USDT")
}

data class OrderBookEntry(
    val price: Double,
    val quantity: Double,
    val total: Double = price * quantity
)

data class OrderBookData(
    val bids: List<OrderBookEntry> = emptyList(),
    val asks: List<OrderBookEntry> = emptyList()
)

data class RecentTrade(
    val id: Long,
    val price: Double,
    val qty: Double,
    val time: Long,
    val isBuyerMaker: Boolean // true = Sell, false = Buy
)

enum class TimeFrame(val label: String, val interval: String, val seconds: Long) {
    M1("1m", "1m", 60),
    M5("5m", "5m", 300),
    M15("15m", "15m", 900),
    H1("1h", "1h", 3600),
    H4("4h", "4h", 14400),
    D1("1D", "1d", 86400)
}

enum class MarketConnectionStatus {
    CONNECTED,
    CONNECTING,
    DISCONNECTED,
    RECONNECTING,
    ERROR
}

enum class FluctuationType(val displayName: String) {
    PRICE_ABOVE("Harga Di Atas (Target Naik)"),
    PRICE_BELOW("Harga Di Bawah (Target Turun)"),
    SPIKE_UP("Lonjakan Naik Cepat (Spike)"),
    DUMP_DOWN("Penurunan Tajam Cepat (Dump)"),
    ANY_VOLATILITY("Fluktuasi Signifikan (Naik/Turun)")
}

data class RollingPricePoint(
    val price: Double,
    val timestamp: Long
)

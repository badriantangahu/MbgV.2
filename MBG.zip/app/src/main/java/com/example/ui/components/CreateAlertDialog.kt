package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAlert
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.FluctuationType
import com.example.ui.theme.BgCard
import com.example.ui.theme.BgCardElevated
import com.example.ui.theme.BgSurface
import com.example.ui.theme.BorderHighlight
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.ImmersiveGreen
import com.example.ui.theme.ImmersiveGreenBg
import com.example.ui.theme.ImmersiveOnPrimary
import com.example.ui.theme.ImmersivePrimary
import com.example.ui.theme.ImmersiveRed
import com.example.ui.theme.ImmersiveTertiary
import com.example.ui.theme.ImmersiveTertiaryContainer
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun CreateAlertDialog(
    initialSymbol: String,
    currentPrice: Double,
    onDismiss: () -> Unit,
    onSaveRule: (
        symbol: String,
        type: FluctuationType,
        targetValue: Double,
        timeframeMinutes: Int,
        sound: Boolean,
        vibrate: Boolean,
        oneShot: Boolean,
        note: String
    ) -> Unit
) {
    var symbol by remember { mutableStateOf(initialSymbol) }
    var selectedType by remember { mutableStateOf(FluctuationType.SPIKE_UP) }
    var targetValueText by remember {
        mutableStateOf(
            if (selectedType == FluctuationType.SPIKE_UP || selectedType == FluctuationType.DUMP_DOWN || selectedType == FluctuationType.ANY_VOLATILITY) {
                "2.0"
            } else {
                String.format(Locale.US, "%.2f", currentPrice * 1.03)
            }
        )
    }
    var timeframeMinutes by remember { mutableIntStateOf(3) }
    var enableSound by remember { mutableStateOf(true) }
    var enableVibration by remember { mutableStateOf(true) }
    var isOneShot by remember { mutableStateOf(false) }
    var noteText by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    val isPercentage = selectedType == FluctuationType.SPIKE_UP ||
            selectedType == FluctuationType.DUMP_DOWN ||
            selectedType == FluctuationType.ANY_VOLATILITY

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .padding(vertical = 16.dp)
                .border(1.dp, BorderHighlight, RoundedCornerShape(28.dp))
                .testTag("create_alert_dialog_card"),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = BgCard)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(ImmersiveTertiaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddAlert,
                                contentDescription = null,
                                tint = ImmersiveTertiary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Text(
                            text = "Buat Alarm Fluktuasi",
                            color = TextPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Symbol Input & Current Price preview
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = symbol,
                        onValueChange = { symbol = it.uppercase().trim() },
                        label = { Text("Simbol Koin (cth: BTCUSDT)") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("alert_symbol_input"),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ImmersivePrimary,
                            unfocusedBorderColor = BorderSubtle,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = BgSurface,
                            unfocusedContainerColor = BgSurface
                        )
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Harga Live", color = TextSecondary, fontSize = 11.sp)
                        Text(
                            text = if (currentPrice > 0) "$${String.format(Locale.US, "%.2f", currentPrice)}" else "-",
                            color = ImmersivePrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Rule Type Selector
                Text("Tipe Pemicu Alarm:", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(6.dp))

                val types = listOf(
                    FluctuationType.SPIKE_UP to "⚡ Lonjakan Naik Cepat (+%)",
                    FluctuationType.DUMP_DOWN to "⚠️ Penurunan Tajam (-%)",
                    FluctuationType.ANY_VOLATILITY to "🔥 Fluktuasi Volatilitas (±%)",
                    FluctuationType.PRICE_ABOVE to "📈 Target Di Atas ($)",
                    FluctuationType.PRICE_BELOW to "📉 Target Di Bawah ($)"
                )

                types.forEach { (type, label) ->
                    val isSelected = selectedType == type
                    val itemBg = if (isSelected) ImmersivePrimary.copy(alpha = 0.15f) else BgSurface
                    val borderColor = if (isSelected) ImmersivePrimary else Color.Transparent

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(itemBg)
                            .border(1.dp, borderColor, RoundedCornerShape(12.dp))
                            .clickable {
                                selectedType = type
                                if (type == FluctuationType.PRICE_ABOVE && currentPrice > 0) {
                                    targetValueText = String.format(Locale.US, "%.2f", currentPrice * 1.03)
                                } else if (type == FluctuationType.PRICE_BELOW && currentPrice > 0) {
                                    targetValueText = String.format(Locale.US, "%.2f", currentPrice * 0.97)
                                } else if ((targetValueText.toDoubleOrNull() ?: 0.0) > 100) {
                                    targetValueText = "2.0"
                                }
                            }
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) ImmersivePrimary else TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Target Value Input
                OutlinedTextField(
                    value = targetValueText,
                    onValueChange = {
                        targetValueText = it
                        errorMessage = ""
                    },
                    label = {
                        Text(if (isPercentage) "Ambang Persentase Bergerak (%)" else "Target Harga ($ USDT)")
                    },
                    placeholder = {
                        Text(if (isPercentage) "Contoh: 2.0 (artinya 2%)" else "Contoh: 98500.00", color = TextMuted)
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("alert_target_value_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ImmersivePrimary,
                        unfocusedBorderColor = BorderSubtle,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = BgSurface,
                        unfocusedContainerColor = BgSurface
                    )
                )

                if (isPercentage) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Rentang Waktu Fluktuasi:", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(1, 3, 5, 15).forEach { mins ->
                            val isTfSelected = timeframeMinutes == mins
                            Surface(
                                color = if (isTfSelected) ImmersivePrimary else BgCardElevated,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { timeframeMinutes = mins }
                            ) {
                                Text(
                                    text = "${mins}m",
                                    color = if (isTfSelected) ImmersiveOnPrimary else TextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Toggles for Sound & Vibration
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.NotificationsActive, contentDescription = null, tint = ImmersivePrimary, modifier = Modifier.size(20.dp))
                        Text("Bunyikan Alarm Ponsel", color = TextPrimary, fontSize = 13.sp)
                    }
                    Switch(
                        checked = enableSound,
                        onCheckedChange = { enableSound = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = ImmersivePrimary,
                            checkedTrackColor = ImmersivePrimary.copy(alpha = 0.35f)
                        )
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Vibration, contentDescription = null, tint = ImmersiveGreen, modifier = Modifier.size(20.dp))
                        Text("Getar Kuat (Vibrate)", color = TextPrimary, fontSize = 13.sp)
                    }
                    Switch(
                        checked = enableVibration,
                        onCheckedChange = { enableVibration = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = ImmersiveGreen,
                            checkedTrackColor = ImmersiveGreen.copy(alpha = 0.35f)
                        )
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Sekali Pakai (One-time)", color = TextPrimary, fontSize = 13.sp)
                        Text("Mati otomatis setelah berbunyi", color = TextSecondary, fontSize = 10.sp)
                    }
                    Switch(
                        checked = isOneShot,
                        onCheckedChange = { isOneShot = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = ImmersivePrimary,
                            checkedTrackColor = ImmersivePrimary.copy(alpha = 0.35f)
                        )
                    )
                }

                if (errorMessage.isNotEmpty()) {
                    Text(
                        text = errorMessage,
                        color = ImmersiveRed,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Save Button
                Button(
                    onClick = {
                        val num = targetValueText.toDoubleOrNull()
                        if (num == null || num <= 0) {
                            errorMessage = "Masukkan angka target yang valid"
                            return@Button
                        }
                        if (symbol.isBlank()) {
                            errorMessage = "Masukkan simbol koin"
                            return@Button
                        }

                        val note = if (isPercentage) {
                            "${selectedType.displayName}: $num% dalam ${timeframeMinutes}m"
                        } else {
                            "${selectedType.displayName}: $$num"
                        }

                        onSaveRule(
                            symbol,
                            selectedType,
                            num,
                            timeframeMinutes,
                            enableSound,
                            enableVibration,
                            isOneShot,
                            note
                        )
                        onDismiss()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("save_alert_rule_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ImmersivePrimary,
                        contentColor = ImmersiveOnPrimary
                    ),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text("AKTIFKAN ALARM INI", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}

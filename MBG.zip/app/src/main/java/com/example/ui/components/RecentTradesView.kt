package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RecentTrade
import com.example.ui.theme.BgCard
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.ImmersiveGreen
import com.example.ui.theme.ImmersiveRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun RecentTradesView(
    trades: List<RecentTrade>,
    modifier: Modifier = Modifier
) {
    val timeFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }

    Column(
        modifier = modifier
            .background(BgCard, RoundedCornerShape(18.dp))
            .border(1.dp, BorderSubtle, RoundedCornerShape(18.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Live Trades", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text("Tick Tape", color = TextSecondary, fontSize = 10.sp)
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Harga", color = TextSecondary, fontSize = 10.sp, modifier = Modifier.weight(1.2f))
            Text("Jumlah", color = TextSecondary, fontSize = 10.sp, modifier = Modifier.weight(1f))
            Text("Waktu", color = TextSecondary, fontSize = 10.sp, modifier = Modifier.weight(0.8f))
        }

        Spacer(modifier = Modifier.height(6.dp))

        val displayTrades = trades.take(8)
        displayTrades.forEach { trade ->
            val isBuy = !trade.isBuyerMaker
            val color = if (isBuy) ImmersiveGreen else ImmersiveRed

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 1.5.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = String.format(Locale.US, "%.2f", trade.price),
                    color = color,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.weight(1.2f)
                )
                Text(
                    text = String.format(Locale.US, "%.3f", trade.qty),
                    color = TextPrimary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = timeFormat.format(Date(trade.time)),
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.weight(0.8f)
                )
            }
        }

        if (displayTrades.isEmpty()) {
            Text("Menunggu tick...", color = TextMuted, fontSize = 10.sp, modifier = Modifier.padding(4.dp))
        }
    }
}

package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CandleData
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.BgCard
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.ImmersiveGreen
import com.example.ui.theme.ImmersivePrimary
import com.example.ui.theme.ImmersiveRed
import com.example.ui.theme.ImmersiveTertiary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

@Composable
fun CandlestickChart(
    candles: List<CandleData>,
    modifier: Modifier = Modifier,
    currentPrice: Double = 0.0
) {
    var selectedIndex by remember { mutableStateOf<Int?>(null) }
    val timeFormat = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }

    if (candles.isEmpty()) {
        Box(
            modifier = modifier
                .background(BgCard, RoundedCornerShape(18.dp))
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("Memuat data candlestick...", color = TextSecondary, fontSize = 13.sp)
        }
        return
    }

    val candleToDisplay = selectedIndex?.let { candles.getOrNull(it) } ?: candles.lastOrNull()

    Column(
        modifier = modifier
            .background(BgCard, RoundedCornerShape(18.dp))
            .padding(8.dp)
            .testTag("candlestick_chart_container")
    ) {
        // Stats header for inspected candle
        if (candleToDisplay != null) {
            val candleChange = candleToDisplay.close - candleToDisplay.open
            val candleChangePct = if (candleToDisplay.open > 0) (candleChange / candleToDisplay.open) * 100 else 0.0
            val isGreen = candleChange >= 0
            val color = if (isGreen) ImmersiveGreen else ImmersiveRed
            val sign = if (isGreen) "+" else ""

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = timeFormat.format(Date(candleToDisplay.openTime)),
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("O: ", color = TextSecondary, fontSize = 10.sp)
                    Text(formatPrice(candleToDisplay.open), color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("H: ", color = TextSecondary, fontSize = 10.sp)
                    Text(formatPrice(candleToDisplay.high), color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("L: ", color = TextSecondary, fontSize = 10.sp)
                    Text(formatPrice(candleToDisplay.low), color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("C: ", color = TextSecondary, fontSize = 10.sp)
                    Text(formatPrice(candleToDisplay.close), color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }

                Text(
                    text = "$sign${String.format(Locale.US, "%.2f", candleChangePct)}%",
                    color = color,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Legend for EMA indicators
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("EMA(7): ", color = ImmersivePrimary, fontSize = 10.sp)
                Text(
                    formatPrice(calculateEma(candles, 7, selectedIndex ?: (candles.size - 1))),
                    color = ImmersivePrimary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text("EMA(25): ", color = ImmersiveTertiary, fontSize = 10.sp)
                Text(
                    formatPrice(calculateEma(candles, 25, selectedIndex ?: (candles.size - 1))),
                    color = ImmersiveTertiary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text("Vol: ", color = TextSecondary, fontSize = 10.sp)
                Text(
                    String.format(Locale.US, "%.2f", candleToDisplay.volume),
                    color = TextSecondary,
                    fontSize = 10.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Main Chart Canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .pointerInput(candles) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            selectedIndex = getIndexFromOffset(offset.x, size.width.toFloat(), candles.size)
                        },
                        onDrag = { change, _ ->
                            change.consume()
                            selectedIndex = getIndexFromOffset(change.position.x, size.width.toFloat(), candles.size)
                        },
                        onDragEnd = {
                            selectedIndex = null
                        },
                        onDragCancel = {
                            selectedIndex = null
                        }
                    )
                }
                .pointerInput(candles) {
                    detectTapGestures { offset ->
                        selectedIndex = getIndexFromOffset(offset.x, size.width.toFloat(), candles.size)
                    }
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val chartWidth = size.width - 55.dp.toPx() // Reserve right side for price scale
                val chartHeight = size.height * 0.78f // Top 78% for candlestick, bottom 22% for volume
                val volumeHeight = size.height * 0.20f
                val volumeTop = size.height - volumeHeight

                val minPrice = candles.minOf { it.low }
                val maxPrice = candles.maxOf { it.high }
                val priceRange = if (maxPrice > minPrice) maxPrice - minPrice else 1.0
                val paddedMin = minPrice - (priceRange * 0.04)
                val paddedMax = maxPrice + (priceRange * 0.04)
                val totalRange = paddedMax - paddedMin

                val maxVolume = candles.maxOfOrNull { it.volume } ?: 1.0

                val count = candles.size
                val stepX = chartWidth / count
                val candleWidth = max(2f, stepX * 0.72f)

                // 1. Draw Grid Lines & Right Price Scale
                val gridSteps = 4
                for (i in 0..gridSteps) {
                    val y = (chartHeight / gridSteps) * i
                    val priceAtGrid = paddedMax - (i / gridSteps.toDouble()) * totalRange

                    // Dotted line
                    drawLine(
                        color = BorderSubtle,
                        start = Offset(0f, y),
                        end = Offset(chartWidth, y),
                        strokeWidth = 1.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                    )

                    // Text price label on the right
                    drawContext.canvas.nativeCanvas.drawText(
                        formatPrice(priceAtGrid),
                        chartWidth + 6.dp.toPx(),
                        y + 4.dp.toPx(),
                        android.graphics.Paint().apply {
                            color = android.graphics.Color.parseColor("#938F99")
                            textSize = 22f
                            isAntiAlias = true
                        }
                    )
                }

                // Volume separator line
                drawLine(
                    color = BorderSubtle,
                    start = Offset(0f, volumeTop),
                    end = Offset(chartWidth, volumeTop),
                    strokeWidth = 1.dp.toPx()
                )

                // 2. Draw Volume Bars
                for (i in 0 until count) {
                    val candle = candles[i]
                    val xCenter = i * stepX + (stepX / 2f)
                    val volRatio = if (maxVolume > 0) (candle.volume / maxVolume).toFloat() else 0f
                    val barHeight = volRatio * volumeHeight
                    val barTop = size.height - barHeight
                    val isGreen = candle.isBullish

                    drawRect(
                        color = if (isGreen) ImmersiveGreen.copy(alpha = 0.45f) else ImmersiveRed.copy(alpha = 0.45f),
                        topLeft = Offset(xCenter - (candleWidth / 2f), barTop),
                        size = Size(candleWidth, barHeight)
                    )
                }

                // 3. Draw Candlesticks & Wicks
                for (i in 0 until count) {
                    val candle = candles[i]
                    val xCenter = i * stepX + (stepX / 2f)
                    val isGreen = candle.isBullish
                    val candleColor = if (isGreen) ImmersiveGreen else ImmersiveRed

                    val highY = (chartHeight * (paddedMax - candle.high) / totalRange).toFloat()
                    val lowY = (chartHeight * (paddedMax - candle.low) / totalRange).toFloat()
                    val openY = (chartHeight * (paddedMax - candle.open) / totalRange).toFloat()
                    val closeY = (chartHeight * (paddedMax - candle.close) / totalRange).toFloat()

                    val bodyTop = min(openY, closeY)
                    val bodyHeight = max(2f, kotlin.math.abs(closeY - openY))

                    // Wick
                    drawLine(
                        color = candleColor,
                        start = Offset(xCenter, highY),
                        end = Offset(xCenter, lowY),
                        strokeWidth = 1.5.dp.toPx()
                    )

                    // Body
                    drawRect(
                        color = candleColor,
                        topLeft = Offset(xCenter - (candleWidth / 2f), bodyTop),
                        size = Size(candleWidth, bodyHeight)
                    )
                }

                // 4. Draw EMAs
                drawEmaLine(candles, 7, ImmersivePrimary, stepX, chartHeight, paddedMax, totalRange)
                drawEmaLine(candles, 25, ImmersiveTertiary, stepX, chartHeight, paddedMax, totalRange)

                // 5. Draw Live Current Price Beacon Line
                if (currentPrice > 0) {
                    val currentY = (chartHeight * (paddedMax - currentPrice) / totalRange).toFloat()
                    if (currentY in 0f..chartHeight) {
                        drawLine(
                            color = ImmersivePrimary,
                            start = Offset(0f, currentY),
                            end = Offset(chartWidth, currentY),
                            strokeWidth = 1.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f), 0f)
                        )

                        // Beacon badge on right
                        drawRect(
                            color = ImmersivePrimary,
                            topLeft = Offset(chartWidth + 2.dp.toPx(), currentY - 8.dp.toPx()),
                            size = Size(50.dp.toPx(), 16.dp.toPx())
                        )
                        drawContext.canvas.nativeCanvas.drawText(
                            formatPrice(currentPrice),
                            chartWidth + 4.dp.toPx(),
                            currentY + 4.dp.toPx(),
                            android.graphics.Paint().apply {
                                color = android.graphics.Color.parseColor("#381E72")
                                textSize = 20f
                                isFakeBoldText = true
                                isAntiAlias = true
                            }
                        )
                    }
                }

                // 6. Draw Crosshair if dragging/inspecting
                selectedIndex?.let { idx ->
                    if (idx in 0 until count) {
                        val c = candles[idx]
                        val cx = idx * stepX + (stepX / 2f)
                        val cy = (chartHeight * (paddedMax - c.close) / totalRange).toFloat()

                        // Vertical crosshair
                        drawLine(
                            color = TextPrimary.copy(alpha = 0.7f),
                            start = Offset(cx, 0f),
                            end = Offset(cx, size.height),
                            strokeWidth = 1.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f)
                        )

                        // Horizontal crosshair
                        drawLine(
                            color = TextPrimary.copy(alpha = 0.7f),
                            start = Offset(0f, cy),
                            end = Offset(chartWidth, cy),
                            strokeWidth = 1.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f)
                        )

                        // Intersection dot
                        drawCircle(
                            color = if (c.isBullish) ImmersiveGreen else ImmersiveRed,
                            radius = 4.dp.toPx(),
                            center = Offset(cx, cy)
                        )
                    }
                }
            }
        }
    }
}

private fun DrawScope.drawEmaLine(
    candles: List<CandleData>,
    period: Int,
    color: Color,
    stepX: Float,
    chartHeight: Float,
    paddedMax: Double,
    totalRange: Double
) {
    if (candles.size < period) return

    val emaValues = calculateEmaList(candles, period)
    val path = Path()
    var started = false

    for (i in emaValues.indices) {
        val ema = emaValues[i] ?: continue
        val x = i * stepX + (stepX / 2f)
        val y = (chartHeight * (paddedMax - ema) / totalRange).toFloat()

        if (!started) {
            path.moveTo(x, y)
            started = true
        } else {
            path.lineTo(x, y)
        }
    }

    drawPath(
        path = path,
        color = color,
        style = Stroke(width = 1.5.dp.toPx())
    )
}

private fun calculateEmaList(candles: List<CandleData>, period: Int): List<Double?> {
    val result = ArrayList<Double?>(candles.size)
    if (candles.isEmpty()) return result

    val k = 2.0 / (period + 1)
    var currentEma: Double? = null

    for (i in candles.indices) {
        val close = candles[i].close
        if (i < period - 1) {
            result.add(null)
        } else if (i == period - 1) {
            val sum = candles.subList(0, period).sumOf { it.close }
            currentEma = sum / period
            result.add(currentEma)
        } else {
            currentEma = (close * k) + (currentEma!! * (1.0 - k))
            result.add(currentEma)
        }
    }
    return result
}

private fun calculateEma(candles: List<CandleData>, period: Int, index: Int): Double {
    val list = calculateEmaList(candles, period)
    return list.getOrNull(index) ?: candles.getOrNull(index)?.close ?: 0.0
}

private fun getIndexFromOffset(x: Float, totalWidth: Float, totalCount: Int): Int {
    if (totalCount <= 0 || totalWidth <= 0) return 0
    val step = (totalWidth - 55f * 2.5f) / totalCount
    val index = (x / step).toInt().coerceIn(0, totalCount - 1)
    return index
}

private fun formatPrice(price: Double): String {
    return when {
        price >= 1000.0 -> String.format(Locale.US, "%,.2f", price)
        price >= 1.0 -> String.format(Locale.US, "%.4f", price)
        price >= 0.0001 -> String.format(Locale.US, "%.6f", price)
        else -> String.format(Locale.US, "%.8f", price)
    }
}

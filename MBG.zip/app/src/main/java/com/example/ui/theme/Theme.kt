package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = ImmersivePrimary,
    onPrimary = ImmersiveOnPrimary,
    primaryContainer = ImmersivePrimaryContainer,
    onPrimaryContainer = ImmersiveOnPrimaryContainer,
    secondary = ImmersiveGreen,
    onSecondary = TextInverse,
    secondaryContainer = ImmersiveGreenBg,
    onSecondaryContainer = ImmersiveGreen,
    tertiary = ImmersiveTertiary,
    onTertiary = ImmersiveOnTertiary,
    tertiaryContainer = ImmersiveTertiaryContainer,
    onTertiaryContainer = ImmersiveTertiary,
    background = ImmersiveBgDarkest,
    onBackground = TextPrimary,
    surface = ImmersiveBgSurface,
    onSurface = TextPrimary,
    surfaceVariant = ImmersiveBgElevated,
    onSurfaceVariant = TextSecondary,
    outline = BorderSubtle,
    outlineVariant = BorderHighlight
)

@Composable
fun BinanceAlarmTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    BinanceAlarmTheme(darkTheme = darkTheme, content = content)
}


package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.CandleData
import com.example.data.model.OrderBookData
import com.example.data.model.RecentTrade
import com.example.data.model.Ticker24h
import com.example.data.model.TimeFrame
import com.example.ui.components.CandlestickChart
import com.example.ui.components.OrderBookDepthView
import com.example.ui.components.RecentTradesView
import com.example.ui.theme.BgCard
import com.example.ui.theme.BgCardElevated
import com.example.ui.theme.BgDarkest
import com.example.ui.theme.BgSurface
import com.example.ui.theme.BorderHighlight
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.ImmersiveGreen
import com.example.ui.theme.ImmersiveGreenBg
import com.example.ui.theme.ImmersiveOnPrimary
import com.example.ui.theme.ImmersivePrimary
import com.example.ui.theme.ImmersiveRed
import com.example.ui.theme.ImmersiveRedBg
import com.example.ui.theme.ImmersiveTertiary
import com.example.ui.theme.ImmersiveTertiaryContainer
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun MarketChartScreen(
    selectedSymbol: String,
    currentTicker: Ticker24h?,
    klines: List<CandleData>,
    isKlinesLoading: Boolean,
    selectedTimeFrame: TimeFrame,
    orderBook: OrderBookData,
    recentTrades: List<RecentTrade>,
    allTickers: List<Ticker24h>,
    onSelectSymbol: (String) -> Unit,
    onSelectTimeFrame: (TimeFrame) -> Unit,
    onRefreshKlines: () -> Unit,
    onQuickAddAlert: (pct: Double, minutes: Int, isSpike: Boolean) -> Unit,
    onOpenCustomAlertDialog: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showSymbolSearchDialog by remember { mutableStateOf(false) }

    val ticker = currentTicker
    val isPositive = (ticker?.priceChangePercent ?: 0.0) >= 0
    val trendColor = if (isPositive) ImmersiveGreen else ImmersiveRed
    val trendBg = if (isPositive) ImmersiveGreenBg else ImmersiveRedBg

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("market_chart_screen"),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // 1. Hero Price Section (Immersive Design)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(28.dp)),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = BgCard)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    // Top header: Symbol Picker Pill & Refresh button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = BgCardElevated,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .clickable { showSymbolSearchDialog = true }
                                .testTag("select_pair_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = selectedSymbol.replace("USDT", " / USDT"),
                                    color = ImmersivePrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Black,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = "Pilih Pasangan",
                                    tint = ImmersivePrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        // Quick Refresh
                        IconButton(
                            onClick = onRefreshKlines,
                            modifier = Modifier.size(36.dp)
                        ) {
                            if (isKlinesLoading) {
                                CircularProgressIndicator(
                                    color = ImmersivePrimary,
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Refresh",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // "Current Price" subheader
                    Text(
                        text = "Current Price",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    // Big Price and Trend Badge
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val priceStr = ticker?.lastPrice?.let { formatPrice(it) } ?: "..."
                        Text(
                            text = "$$priceStr",
                            color = TextPrimary,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = (-0.5).sp
                        )

                        // 24h Change Pill Badge
                        val changePct = ticker?.priceChangePercent ?: 0.0
                        val sign = if (changePct >= 0) "+" else ""
                        Surface(
                            color = trendBg,
                            shape = RoundedCornerShape(100.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = if (changePct >= 0) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                                    contentDescription = null,
                                    tint = trendColor,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = "$sign${String.format(Locale.US, "%.2f", changePct)}%",
                                    color = trendColor,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // 24h stats row with background highlight
                    Surface(
                        color = BgSurface,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("24h High", color = TextSecondary, fontSize = 10.sp)
                                Text(
                                    text = ticker?.highPrice?.let { "$${formatPrice(it)}" } ?: "-",
                                    color = TextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Column {
                                Text("24h Low", color = TextSecondary, fontSize = 10.sp)
                                Text(
                                    text = ticker?.lowPrice?.let { "$${formatPrice(it)}" } ?: "-",
                                    color = TextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("24h Volume", color = TextSecondary, fontSize = 10.sp)
                                Text(
                                    text = ticker?.volume?.let { String.format(Locale.US, "%.2f", it) } ?: "-",
                                    color = TextSecondary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. TimeFrame Selector Pills
        item {
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(TimeFrame.entries) { tf ->
                    val isSelected = selectedTimeFrame == tf
                    Surface(
                        color = if (isSelected) ImmersivePrimary else BgCardElevated,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .clickable { onSelectTimeFrame(tf) }
                            .testTag("timeframe_${tf.label}")
                    ) {
                        Text(
                            text = tf.label,
                            color = if (isSelected) ImmersiveOnPrimary else TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Black else FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 7.dp)
                        )
                    }
                }
            }
        }

        // 3. Interactive Candlestick Chart Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(310.dp)
                    .padding(horizontal = 14.dp, vertical = 6.dp)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(24.dp)),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = BgCard)
            ) {
                Box(modifier = Modifier.fillMaxSize().padding(10.dp)) {
                    CandlestickChart(
                        candles = klines,
                        currentPrice = ticker?.lastPrice ?: 0.0,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }

        // 4. Fluctuation Threshold & Smart Alarm Section (Immersive Card)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp)
                    .border(1.dp, BorderHighlight, RoundedCornerShape(24.dp)),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = BgCardElevated)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    // Header row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Fluctuation Threshold",
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Surface(
                            color = ImmersivePrimary.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(100.dp)
                        ) {
                            Text(
                                text = "± 0.5% / 1m",
                                color = ImmersivePrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Visual Threshold Bar
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(BorderSubtle)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.65f)
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(ImmersivePrimary)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Smart Alarm row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(ImmersiveTertiaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.NotificationsActive,
                                    contentDescription = null,
                                    tint = ImmersiveTertiary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            Column {
                                Text(
                                    text = "Smart Phone Alarm",
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Bypass Do Not Disturb & ring instantly",
                                    color = TextSecondary,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        Surface(
                            color = ImmersivePrimary,
                            shape = RoundedCornerShape(100.dp),
                            modifier = Modifier
                                .clickable { onOpenCustomAlertDialog() }
                                .testTag("open_custom_alert_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Tune,
                                    contentDescription = null,
                                    tint = ImmersiveOnPrimary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = "Custom",
                                    color = ImmersiveOnPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Quick Alert Preset Chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        QuickAlertChip(
                            title = "+1.0%",
                            subtitle = "3 min",
                            color = ImmersiveGreen,
                            bgColor = ImmersiveGreenBg,
                            modifier = Modifier.weight(1f),
                            onClick = { onQuickAddAlert(1.0, 3, true) }
                        )
                        QuickAlertChip(
                            title = "+2.5%",
                            subtitle = "Surge",
                            color = ImmersiveGreen,
                            bgColor = ImmersiveGreenBg,
                            modifier = Modifier.weight(1f),
                            onClick = { onQuickAddAlert(2.5, 3, true) }
                        )
                        QuickAlertChip(
                            title = "-1.0%",
                            subtitle = "3 min",
                            color = ImmersiveRed,
                            bgColor = ImmersiveRedBg,
                            modifier = Modifier.weight(1f),
                            onClick = { onQuickAddAlert(1.0, 3, false) }
                        )
                        QuickAlertChip(
                            title = "-2.5%",
                            subtitle = "Dump",
                            color = ImmersiveRed,
                            bgColor = ImmersiveRedBg,
                            modifier = Modifier.weight(1f),
                            onClick = { onQuickAddAlert(2.5, 5, false) }
                        )
                    }
                }
            }
        }

        // 5. Orderbook & Live Trades split views
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                OrderBookDepthView(
                    orderBook = orderBook,
                    modifier = Modifier
                        .weight(1.1f)
                        .padding(end = 4.dp)
                )
                RecentTradesView(
                    trades = recentTrades,
                    modifier = Modifier
                        .weight(0.9f)
                        .padding(start = 4.dp)
                )
            }
        }
    }

    // Pair search dialog
    if (showSymbolSearchDialog) {
        SymbolSearchDialog(
            tickers = allTickers,
            currentSymbol = selectedSymbol,
            onDismiss = { showSymbolSearchDialog = false },
            onSelect = { sym ->
                onSelectSymbol(sym)
                showSymbolSearchDialog = false
            }
        )
    }
}

@Composable
private fun QuickAlertChip(
    title: String,
    subtitle: String,
    color: Color,
    bgColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        color = bgColor,
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
            .border(1.dp, color.copy(alpha = 0.3f), RoundedCornerShape(14.dp))
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = title, color = color, fontSize = 12.sp, fontWeight = FontWeight.Black)
            Text(text = subtitle, color = TextSecondary, fontSize = 9.sp)
        }
    }
}

@Composable
private fun SymbolSearchDialog(
    tickers: List<Ticker24h>,
    currentSymbol: String,
    onDismiss: () -> Unit,
    onSelect: (String) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(query, tickers) {
        if (query.isBlank()) tickers else tickers.filter { it.symbol.contains(query.trim(), ignoreCase = true) }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .border(1.dp, BorderHighlight, RoundedCornerShape(24.dp)),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = BgCard)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Pilih Pasangan Binance",
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Tutup", tint = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Cari koin (cth: SOL, ETH, BTC)...", color = TextMuted, fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = ImmersivePrimary) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("symbol_search_text_field"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ImmersivePrimary,
                        unfocusedBorderColor = BorderSubtle,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = BgSurface,
                        unfocusedContainerColor = BgSurface
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(modifier = Modifier.height(300.dp)) {
                    items(filtered) { t ->
                        val isCurrent = t.symbol == currentSymbol
                        val isGain = t.priceChangePercent >= 0
                        val gainColor = if (isGain) ImmersiveGreen else ImmersiveRed

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isCurrent) BgCardElevated else Color.Transparent)
                                .clickable { onSelect(t.symbol) }
                                .padding(horizontal = 10.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = t.symbol,
                                    color = if (isCurrent) ImmersivePrimary else TextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "Vol: ${String.format(Locale.US, "%.0f", t.volume)}",
                                    color = TextSecondary,
                                    fontSize = 10.sp
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "$${formatPrice(t.lastPrice)}",
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "${if (isGain) "+" else ""}${String.format(Locale.US, "%.2f", t.priceChangePercent)}%",
                                    color = gainColor,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun formatPrice(price: Double): String {
    return when {
        price >= 1000.0 -> String.format(Locale.US, "%,.2f", price)
        price >= 1.0 -> String.format(Locale.US, "%.4f", price)
        price >= 0.0001 -> String.format(Locale.US, "%.6f", price)
        else -> String.format(Locale.US, "%.8f", price)
    }
}

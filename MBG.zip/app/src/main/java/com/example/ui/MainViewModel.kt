package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.alarm.AlarmAudioManager
import com.example.alarm.AlarmSoundType
import com.example.alarm.NotificationHelper
import com.example.data.api.BinanceApiService
import com.example.data.api.BinanceWebSocketClient
import com.example.data.db.AlertHistoryEntity
import com.example.data.db.AlertRepository
import com.example.data.db.AlertRuleEntity
import com.example.data.db.AppDatabase
import com.example.data.model.CandleData
import com.example.data.model.FluctuationType
import com.example.data.model.MarketConnectionStatus
import com.example.data.model.OrderBookData
import com.example.data.model.RecentTrade
import com.example.data.model.Ticker24h
import com.example.data.model.TimeFrame
import com.example.domain.FluctuationEngine
import com.example.service.BinancePriceMonitorService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val apiService = BinanceApiService()
    private val webSocketClient = BinanceWebSocketClient()
    private val database = AppDatabase.getInstance(application)
    private val repository = AlertRepository(database.alertDao())

    val fluctuationEngine = BinancePriceMonitorService.sharedEngine ?: FluctuationEngine(application, repository)

    // State flows from Room
    val allRules: StateFlow<List<AlertRuleEntity>> = repository.allRules
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val alertHistory: StateFlow<List<AlertHistoryEntity>> = repository.history
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Alarm states
    val isAlarmRinging: StateFlow<Boolean> = AlarmAudioManager.isAlarmCurrentlyRinging
    val activeRingingInfo: StateFlow<AlertHistoryEntity?> = AlarmAudioManager.activeAlertInfo
    val isServiceRunning: StateFlow<Boolean> = BinancePriceMonitorService.isServiceRunning

    // Market selection states
    private val _selectedSymbol = MutableStateFlow("BTCUSDT")
    val selectedSymbol: StateFlow<String> = _selectedSymbol.asStateFlow()

    private val _selectedTimeFrame = MutableStateFlow(TimeFrame.M15)
    val selectedTimeFrame: StateFlow<TimeFrame> = _selectedTimeFrame.asStateFlow()

    private val _currentTicker = MutableStateFlow<Ticker24h?>(null)
    val currentTicker: StateFlow<Ticker24h?> = _currentTicker.asStateFlow()

    private val _klines = MutableStateFlow<List<CandleData>>(emptyList())
    val klines: StateFlow<List<CandleData>> = _klines.asStateFlow()

    private val _isKlinesLoading = MutableStateFlow(false)
    val isKlinesLoading: StateFlow<Boolean> = _isKlinesLoading.asStateFlow()

    private val _orderBook = MutableStateFlow(OrderBookData())
    val orderBook: StateFlow<OrderBookData> = _orderBook.asStateFlow()

    private val _recentTrades = MutableStateFlow<List<RecentTrade>>(emptyList())
    val recentTrades: StateFlow<List<RecentTrade>> = _recentTrades.asStateFlow()

    private val _allTickers = MutableStateFlow<List<Ticker24h>>(emptyList())
    val allTickers: StateFlow<List<Ticker24h>> = _allTickers.asStateFlow()

    val connectionStatus: StateFlow<MarketConnectionStatus> = webSocketClient.connectionStatus

    // Settings
    private val _selectedSoundType = MutableStateFlow(AlarmAudioManager.selectedSoundType)
    val selectedSoundType: StateFlow<AlarmSoundType> = _selectedSoundType.asStateFlow()

    private val _isVibrationEnabled = MutableStateFlow(AlarmAudioManager.isVibrationEnabled)
    val isVibrationEnabled: StateFlow<Boolean> = _isVibrationEnabled.asStateFlow()

    private val _globalSentinelEnabled = MutableStateFlow(fluctuationEngine.isGlobalSentinelEnabled)
    val globalSentinelEnabled: StateFlow<Boolean> = _globalSentinelEnabled.asStateFlow()

    private val _globalThresholdPct = MutableStateFlow(fluctuationEngine.globalThresholdPercent)
    val globalThresholdPct: StateFlow<Double> = _globalThresholdPct.asStateFlow()

    private var pollJob: Job? = null
    private var chartUpdateJob: Job? = null

    init {
        NotificationHelper.createNotificationChannels(application)
        startServiceIfWanted()
        observeWebSocket()
        loadInitialData()
        startFastPolling()
    }

    private fun startServiceIfWanted() {
        try {
            BinancePriceMonitorService.start(getApplication())
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun observeWebSocket() {
        viewModelScope.launch {
            webSocketClient.liveTicker.collect { ticker ->
                if (ticker.symbol.equals(_selectedSymbol.value, ignoreCase = true)) {
                    _currentTicker.value = ticker
                }
                fluctuationEngine.processPriceUpdate(ticker)
                updateTickerInList(ticker)
            }
        }

        viewModelScope.launch {
            webSocketClient.liveTrade.collect { trade ->
                val current = _recentTrades.value.toMutableList()
                current.add(0, trade)
                if (current.size > 25) {
                    _recentTrades.value = current.take(25)
                } else {
                    _recentTrades.value = current
                }
            }
        }

        viewModelScope.launch {
            webSocketClient.liveCandle.collect { candle ->
                updateLatestCandle(candle)
            }
        }

        viewModelScope.launch {
            webSocketClient.allMiniTickers.collect { list ->
                for (t in list) {
                    fluctuationEngine.processPriceUpdate(t)
                    updateTickerInList(t)
                }
            }
        }
    }

    private fun loadInitialData() {
        val sym = _selectedSymbol.value
        webSocketClient.connect(sym)
        refreshKlines()
        fetch24hTicker(sym)
        fetchOrderBook(sym)
        fetchRecentTrades(sym)
        fetchAllTickers()
    }

    private fun startFastPolling() {
        pollJob?.cancel()
        pollJob = viewModelScope.launch(Dispatchers.IO) {
            while (isActive) {
                val sym = _selectedSymbol.value
                fetchOrderBook(sym)
                fetchAllTickers()
                delay(3000)
            }
        }
    }

    fun selectSymbol(symbol: String) {
        val clean = symbol.uppercase()
        if (_selectedSymbol.value == clean) return

        _selectedSymbol.value = clean
        _currentTicker.value = null
        _recentTrades.value = emptyList()
        _orderBook.value = OrderBookData()

        webSocketClient.connect(clean)
        refreshKlines()
        fetch24hTicker(clean)
        fetchOrderBook(clean)
        fetchRecentTrades(clean)
    }

    fun selectTimeFrame(timeFrame: TimeFrame) {
        _selectedTimeFrame.value = timeFrame
        refreshKlines()
    }

    fun refreshKlines() {
        val sym = _selectedSymbol.value
        val interval = _selectedTimeFrame.value.interval
        _isKlinesLoading.value = true

        viewModelScope.launch(Dispatchers.IO) {
            val result = apiService.getKlines(sym, interval, limit = 80)
            result.onSuccess { list ->
                _klines.value = list
                _isKlinesLoading.value = false
            }.onFailure {
                _isKlinesLoading.value = false
            }
        }
    }

    private fun fetch24hTicker(symbol: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val result = apiService.getTicker24h(symbol)
            result.onSuccess { ticker ->
                _currentTicker.value = ticker
                fluctuationEngine.processPriceUpdate(ticker)
                updateTickerInList(ticker)
            }
        }
    }

    private fun fetchOrderBook(symbol: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val result = apiService.getOrderBook(symbol, limit = 15)
            result.onSuccess { depth ->
                _orderBook.value = depth
            }
        }
    }

    private fun fetchRecentTrades(symbol: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val result = apiService.getRecentTrades(symbol, limit = 25)
            result.onSuccess { trades ->
                _recentTrades.value = trades
            }
        }
    }

    private fun fetchAllTickers() {
        viewModelScope.launch(Dispatchers.IO) {
            val result = apiService.getTopTickers24h()
            result.onSuccess { list ->
                _allTickers.value = list
                for (t in list) {
                    fluctuationEngine.processPriceUpdate(t)
                }
            }
        }
    }

    private fun updateTickerInList(ticker: Ticker24h) {
        val list = _allTickers.value.toMutableList()
        val index = list.indexOfFirst { it.symbol.equals(ticker.symbol, ignoreCase = true) }
        if (index != -1) {
            list[index] = ticker
            _allTickers.value = list
        } else {
            list.add(ticker)
            _allTickers.value = list
        }
    }

    private fun updateLatestCandle(candle: CandleData) {
        val currentList = _klines.value.toMutableList()
        if (currentList.isEmpty()) {
            currentList.add(candle)
            _klines.value = currentList
            return
        }

        val lastIndex = currentList.size - 1
        val last = currentList[lastIndex]

        if (candle.openTime == last.openTime) {
            currentList[lastIndex] = candle
        } else if (candle.openTime > last.openTime) {
            currentList.add(candle)
            if (currentList.size > 100) {
                currentList.removeAt(0)
            }
        }
        _klines.value = currentList
    }

    // Rules Management
    fun createAlertRule(
        symbol: String,
        ruleType: FluctuationType,
        targetValue: Double,
        timeframeMinutes: Int = 3,
        triggerSound: Boolean = true,
        triggerVibration: Boolean = true,
        isOneShot: Boolean = false,
        notes: String = ""
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val currentPrice = _currentTicker.value?.lastPrice ?: 0.0
            val rule = AlertRuleEntity(
                symbol = symbol.uppercase(),
                ruleType = ruleType.name,
                targetValue = targetValue,
                timeframeMinutes = timeframeMinutes,
                basePriceAtCreation = currentPrice,
                isEnabled = true,
                triggerAlarmSound = triggerSound,
                triggerVibration = triggerVibration,
                isOneShot = isOneShot,
                cooldownSeconds = 120,
                notes = notes
            )
            repository.insertRule(rule)
        }
    }

    fun quickAddFluctuationAlert(symbol: String, pct: Double, minutes: Int, isSpike: Boolean) {
        val type = if (isSpike) FluctuationType.SPIKE_UP else FluctuationType.DUMP_DOWN
        val note = if (isSpike) "Lonjakan +$pct% dalam ${minutes}m" else "Penurunan -$pct% dalam ${minutes}m"
        createAlertRule(
            symbol = symbol,
            ruleType = type,
            targetValue = pct,
            timeframeMinutes = minutes,
            triggerSound = true,
            triggerVibration = true,
            isOneShot = false,
            notes = note
        )
    }

    fun toggleRule(id: Long, isEnabled: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.setRuleEnabled(id, isEnabled)
        }
    }

    fun deleteRule(rule: AlertRuleEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteRule(rule)
        }
    }

    fun clearAlertHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearHistory()
        }
    }

    fun deleteHistoryItem(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteHistoryItem(id)
        }
    }

    fun stopCurrentAlarm() {
        AlarmAudioManager.stopAlarm()
        NotificationHelper.cancelAlarmNotification(getApplication())
    }

    fun testAlarmNow(soundType: AlarmSoundType = _selectedSoundType.value) {
        val currentPrice = _currentTicker.value?.lastPrice ?: 95400.0
        val testItem = AlertHistoryEntity(
            ruleId = 999,
            symbol = _selectedSymbol.value,
            title = "🔔 UJI COBA ALARM & GETAR",
            message = "Alarm ponsel dan notifikasi berhasil terpicu secara real-time!",
            ruleType = FluctuationType.SPIKE_UP.name,
            priceBefore = currentPrice * 0.97,
            priceTriggered = currentPrice,
            changePercent = 3.09,
            timestamp = System.currentTimeMillis(),
            isAlarmTriggered = true
        )
        AlarmAudioManager.triggerAlarm(
            context = getApplication(),
            alertInfo = testItem,
            soundType = soundType,
            enableVibration = _isVibrationEnabled.value
        )
        NotificationHelper.showPriceAlarmNotification(getApplication(), testItem)
    }

    fun setSoundType(type: AlarmSoundType) {
        _selectedSoundType.value = type
        AlarmAudioManager.selectedSoundType = type
    }

    fun setVibrationEnabled(enabled: Boolean) {
        _isVibrationEnabled.value = enabled
        AlarmAudioManager.isVibrationEnabled = enabled
    }

    fun setGlobalSentinel(enabled: Boolean, thresholdPct: Double = 2.0, windowMinutes: Int = 3) {
        _globalSentinelEnabled.value = enabled
        _globalThresholdPct.value = thresholdPct
        fluctuationEngine.isGlobalSentinelEnabled = enabled
        fluctuationEngine.globalThresholdPercent = thresholdPct
        fluctuationEngine.globalWindowMinutes = windowMinutes
    }

    fun toggleBackgroundService(enable: Boolean) {
        if (enable) {
            BinancePriceMonitorService.start(getApplication())
        } else {
            BinancePriceMonitorService.stop(getApplication())
        }
    }

    override fun onCleared() {
        super.onCleared()
        pollJob?.cancel()
        chartUpdateJob?.cancel()
        webSocketClient.disconnect()
    }
}

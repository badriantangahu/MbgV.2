package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MarketConnectionStatus
import com.example.ui.MainViewModel
import com.example.ui.components.ActiveAlarmBanner
import com.example.ui.components.ActiveAlarmDialog
import com.example.ui.components.CreateAlertDialog
import com.example.ui.theme.BgCard
import com.example.ui.theme.BgCardElevated
import com.example.ui.theme.BgDarkest
import com.example.ui.theme.BgSurface
import com.example.ui.theme.BinanceGold
import com.example.ui.theme.BinanceGreen
import com.example.ui.theme.BinanceRed
import com.example.ui.theme.BorderHighlight
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.ImmersiveOnPrimary
import com.example.ui.theme.ImmersiveOnPrimaryContainer
import com.example.ui.theme.ImmersivePrimary
import com.example.ui.theme.ImmersivePrimaryContainer
import com.example.ui.theme.ImmersiveTertiary
import com.example.ui.theme.ImmersiveTertiaryContainer
import com.example.ui.theme.TextInverse
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

enum class AppTab(val label: String, val icon: ImageVector) {
    CHART("Grafik", Icons.Default.ShowChart),
    WATCHLIST("Pasar", Icons.Default.ViewList),
    RULES("Alarm", Icons.Default.NotificationsActive),
    HISTORY("Riwayat", Icons.Default.History),
    SETTINGS("Setelan", Icons.Default.Settings)
}

@Composable
fun MainAppContainer(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    var currentTab by remember { mutableStateOf(AppTab.CHART) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var targetSymbolForDialog by remember { mutableStateOf("BTCUSDT") }

    val selectedSymbol by viewModel.selectedSymbol.collectAsState()
    val selectedTimeFrame by viewModel.selectedTimeFrame.collectAsState()
    val currentTicker by viewModel.currentTicker.collectAsState()
    val klines by viewModel.klines.collectAsState()
    val isKlinesLoading by viewModel.isKlinesLoading.collectAsState()
    val orderBook by viewModel.orderBook.collectAsState()
    val recentTrades by viewModel.recentTrades.collectAsState()
    val allTickers by viewModel.allTickers.collectAsState()
    val connectionStatus by viewModel.connectionStatus.collectAsState()

    val allRules by viewModel.allRules.collectAsState()
    val alertHistory by viewModel.alertHistory.collectAsState()

    val isAlarmRinging by viewModel.isAlarmRinging.collectAsState()
    val activeAlarmInfo by viewModel.activeRingingInfo.collectAsState()
    val isServiceRunning by viewModel.isServiceRunning.collectAsState()

    val selectedSoundType by viewModel.selectedSoundType.collectAsState()
    val isVibrationEnabled by viewModel.isVibrationEnabled.collectAsState()
    val globalSentinelEnabled by viewModel.globalSentinelEnabled.collectAsState()
    val globalThresholdPct by viewModel.globalThresholdPct.collectAsState()

    val infiniteTransition = rememberInfiniteTransition(label = "top_dot_pulse")
    val dotPulse by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(600),
            repeatMode = RepeatMode.Reverse
        ),
        label = "dot_scale"
    )

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = BgDarkest,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            // Immersive Header styled according to the design specification
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Avatar circle with lavender accent
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(ImmersivePrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Analytics,
                            contentDescription = null,
                            tint = ImmersiveOnPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Binance Pulse",
                                color = TextPrimary,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            val dotColor = when (connectionStatus) {
                                MarketConnectionStatus.CONNECTED -> BinanceGreen
                                MarketConnectionStatus.CONNECTING,
                                MarketConnectionStatus.RECONNECTING -> ImmersiveTertiary
                                MarketConnectionStatus.ERROR -> BinanceRed
                                MarketConnectionStatus.DISCONNECTED -> TextMuted
                            }
                            val statusText = when (connectionStatus) {
                                MarketConnectionStatus.CONNECTED -> "LIVE STREAM CONNECTED"
                                MarketConnectionStatus.CONNECTING,
                                MarketConnectionStatus.RECONNECTING -> "SYNCING FEED..."
                                MarketConnectionStatus.ERROR -> "STREAM OFFLINE"
                                MarketConnectionStatus.DISCONNECTED -> "DISCONNECTED"
                            }
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .scale(if (connectionStatus == MarketConnectionStatus.CONNECTED) dotPulse else 1f)
                                    .background(dotColor, CircleShape)
                            )
                            Text(
                                text = statusText,
                                color = TextSecondary,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.SemiBold,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                }

                // Top right action: Notification/Alarm button
                if (isAlarmRinging) {
                    Surface(
                        color = BinanceRed,
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .testTag("top_bar_stop_alarm_btn")
                            .clickable { viewModel.stopCurrentAlarm() }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeOff,
                                contentDescription = "Stop",
                                tint = TextInverse,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "STOP",
                                color = TextInverse,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(BgCardElevated)
                            .clickable { viewModel.testAlarmNow() }
                            .testTag("test_alarm_top_icon"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = "Test Alarm",
                            tint = ImmersivePrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BgSurface)
            ) {
                // Subtle top border for bottom nav
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(BorderSubtle)
                )

                NavigationBar(
                    containerColor = BgSurface,
                    tonalElevation = 0.dp,
                    modifier = Modifier
                        .navigationBarsPadding()
                        .testTag("main_bottom_nav")
                ) {
                    AppTab.entries.forEach { tab ->
                        val isSelected = currentTab == tab
                        val activeCount = if (tab == AppTab.RULES) allRules.count { it.isEnabled } else 0

                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { currentTab = tab },
                            icon = {
                                if (activeCount > 0 && tab == AppTab.RULES) {
                                    BadgedBox(
                                        badge = {
                                            Badge(
                                                containerColor = ImmersivePrimary,
                                                contentColor = ImmersiveOnPrimary
                                            ) {
                                                Text("$activeCount", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    ) {
                                        Icon(imageVector = tab.icon, contentDescription = tab.label)
                                    }
                                } else {
                                    Icon(imageVector = tab.icon, contentDescription = tab.label)
                                }
                            },
                            label = {
                                Text(
                                    text = tab.label,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = ImmersiveOnPrimaryContainer,
                                selectedTextColor = ImmersivePrimary,
                                indicatorColor = ImmersivePrimaryContainer,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            )
                        )
                    }
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Active Alarm Banner if ringing
            ActiveAlarmBanner(
                isRinging = isAlarmRinging,
                alertInfo = activeAlarmInfo,
                onStopAlarm = { viewModel.stopCurrentAlarm() }
            )

            when (currentTab) {
                AppTab.CHART -> {
                    MarketChartScreen(
                        selectedSymbol = selectedSymbol,
                        currentTicker = currentTicker,
                        klines = klines,
                        isKlinesLoading = isKlinesLoading,
                        selectedTimeFrame = selectedTimeFrame,
                        orderBook = orderBook,
                        recentTrades = recentTrades,
                        allTickers = allTickers,
                        onSelectSymbol = { sym -> viewModel.selectSymbol(sym) },
                        onSelectTimeFrame = { tf -> viewModel.selectTimeFrame(tf) },
                        onRefreshKlines = { viewModel.refreshKlines() },
                        onQuickAddAlert = { pct, min, isSpike ->
                            viewModel.quickAddFluctuationAlert(selectedSymbol, pct, min, isSpike)
                        },
                        onOpenCustomAlertDialog = {
                            targetSymbolForDialog = selectedSymbol
                            showCreateDialog = true
                        }
                    )
                }
                AppTab.WATCHLIST -> {
                    WatchlistScreen(
                        tickers = allTickers,
                        onSelectCoin = { sym ->
                            viewModel.selectSymbol(sym)
                            currentTab = AppTab.CHART
                        },
                        onQuickSetAlarm = { sym ->
                            targetSymbolForDialog = sym
                            showCreateDialog = true
                        }
                    )
                }
                AppTab.RULES -> {
                    AlertRulesScreen(
                        rules = allRules,
                        isGlobalSentinelEnabled = globalSentinelEnabled,
                        globalThresholdPct = globalThresholdPct,
                        onToggleGlobalSentinel = { en, pct ->
                            viewModel.setGlobalSentinel(en, pct)
                        },
                        onToggleRule = { id, enabled ->
                            viewModel.toggleRule(id, enabled)
                        },
                        onDeleteRule = { rule ->
                            viewModel.deleteRule(rule)
                        },
                        onOpenCreateDialog = {
                            targetSymbolForDialog = selectedSymbol
                            showCreateDialog = true
                        }
                    )
                }
                AppTab.HISTORY -> {
                    AlertHistoryScreen(
                        history = alertHistory,
                        onClearHistory = { viewModel.clearAlertHistory() }
                    )
                }
                AppTab.SETTINGS -> {
                    AlarmSettingsScreen(
                        selectedSoundType = selectedSoundType,
                        isVibrationEnabled = isVibrationEnabled,
                        isServiceRunning = isServiceRunning,
                        onSelectSoundType = { viewModel.setSoundType(it) },
                        onToggleVibration = { viewModel.setVibrationEnabled(it) },
                        onToggleService = { viewModel.toggleBackgroundService(it) },
                        onTestAlarm = { sound -> viewModel.testAlarmNow(sound) }
                    )
                }
            }
        }
    }

    // Active Alarm Emergency Pop-up Dialog
    if (isAlarmRinging && activeAlarmInfo != null) {
        ActiveAlarmDialog(
            alertInfo = activeAlarmInfo!!,
            onDismissAndStop = { viewModel.stopCurrentAlarm() }
        )
    }

    // Create Rule Dialog
    if (showCreateDialog) {
        val currentPrice = currentTicker?.lastPrice ?: 0.0
        CreateAlertDialog(
            initialSymbol = targetSymbolForDialog,
            currentPrice = currentPrice,
            onDismiss = { showCreateDialog = false },
            onSaveRule = { sym, type, target, tf, sound, vib, oneShot, note ->
                viewModel.createAlertRule(
                    symbol = sym,
                    ruleType = type,
                    targetValue = target,
                    timeframeMinutes = tf,
                    triggerSound = sound,
                    triggerVibration = vib,
                    isOneShot = oneShot,
                    notes = note
                )
            }
        )
    }
}


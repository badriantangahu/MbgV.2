package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.OrderBookData
import com.example.data.model.OrderBookEntry
import com.example.ui.theme.BgCard
import com.example.ui.theme.BgCardElevated
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.ImmersiveGreen
import com.example.ui.theme.ImmersiveGreenBg
import com.example.ui.theme.ImmersiveRed
import com.example.ui.theme.ImmersiveRedBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale
import kotlin.math.max

@Composable
fun OrderBookDepthView(
    orderBook: OrderBookData,
    modifier: Modifier = Modifier
) {
    val topBids = orderBook.bids.take(8)
    val topAsks = orderBook.asks.take(8)

    val maxBidQty = topBids.maxOfOrNull { it.quantity } ?: 1.0
    val maxAskQty = topAsks.maxOfOrNull { it.quantity } ?: 1.0
    val maxQty = max(maxBidQty, maxAskQty)

    Column(
        modifier = modifier
            .background(BgCard, RoundedCornerShape(18.dp))
            .border(1.dp, BorderSubtle, RoundedCornerShape(18.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Order Book", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text("Kedalaman", color = TextSecondary, fontSize = 10.sp)
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Beli (Bids)", color = ImmersiveGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text("Jual (Asks)", color = ImmersiveRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(modifier = Modifier.fillMaxWidth()) {
            // Bids Column
            Column(modifier = Modifier.weight(1f)) {
                topBids.forEach { bid ->
                    OrderBookRow(
                        entry = bid,
                        isBid = true,
                        maxQty = maxQty
                    )
                }
                if (topBids.isEmpty()) {
                    Text("Memuat...", color = TextMuted, fontSize = 10.sp, modifier = Modifier.padding(4.dp))
                }
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Asks Column
            Column(modifier = Modifier.weight(1f)) {
                topAsks.forEach { ask ->
                    OrderBookRow(
                        entry = ask,
                        isBid = false,
                        maxQty = maxQty
                    )
                }
                if (topAsks.isEmpty()) {
                    Text("Memuat...", color = TextMuted, fontSize = 10.sp, modifier = Modifier.padding(4.dp))
                }
            }
        }
    }
}

@Composable
private fun OrderBookRow(
    entry: OrderBookEntry,
    isBid: Boolean,
    maxQty: Double
) {
    val fillRatio = if (maxQty > 0) (entry.quantity / maxQty).toFloat().coerceIn(0.05f, 1f) else 0.1f
    val color = if (isBid) ImmersiveGreen else ImmersiveRed
    val bgColor = if (isBid) ImmersiveGreenBg else ImmersiveRedBg

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(18.dp)
            .padding(vertical = 1.dp)
    ) {
        // Background depth bar
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(fillRatio)
                .align(if (isBid) Alignment.CenterStart else Alignment.CenterEnd)
                .background(bgColor, RoundedCornerShape(2.dp))
        )

        // Text content
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = formatOrderPrice(entry.price),
                color = color,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = String.format(Locale.US, "%.3f", entry.quantity),
                color = TextSecondary,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

private fun formatOrderPrice(price: Double): String {
    return when {
        price >= 1000.0 -> String.format(Locale.US, "%.2f", price)
        price >= 1.0 -> String.format(Locale.US, "%.4f", price)
        else -> String.format(Locale.US, "%.6f", price)
    }
}

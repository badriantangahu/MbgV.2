package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Immersive UI Palette - Dark & Expressive Lavender/Purple Accents
val ImmersiveBgDarkest = Color(0xFF121212)
val ImmersiveBgSurface = Color(0xFF1C1B1F)
val ImmersiveBgCard = Color(0xFF1E1E1E)
val ImmersiveBgElevated = Color(0xFF2B2930)
val ImmersiveBgSelected = Color(0xFF36343B)

// Accents (Lavender / Purple)
val ImmersivePrimary = Color(0xFFD0BCFF)
val ImmersiveOnPrimary = Color(0xFF381E72)
val ImmersivePrimaryContainer = Color(0xFFE8DEF8)
val ImmersiveOnPrimaryContainer = Color(0xFF1D192B)

// Alarm & Warning Accents (Mauve / Pinkish tertiary)
val ImmersiveTertiary = Color(0xFFFFD8E4)
val ImmersiveOnTertiary = Color(0xFF633B48)
val ImmersiveTertiaryContainer = Color(0xFF492532)

// Market Signals (Green Spike & Red Dump)
val ImmersiveGreen = Color(0xFF22C55E)
val ImmersiveGreenLight = Color(0xFF4ADE80)
val ImmersiveGreenBg = Color(0x2622C55E)
val ImmersiveGreenDark = Color(0xFF14532D)

val ImmersiveRed = Color(0xFFEF4444)
val ImmersiveRedLight = Color(0xFFF87171)
val ImmersiveRedBg = Color(0x26EF4444)
val ImmersiveRedDark = Color(0xFF7F1D1D)

// Binance Yellow/Gold Accent for Binance identity
val BinanceGold = Color(0xFFF0B90B)
val BinanceGoldLight = Color(0xFFFCD535)
val BinanceGoldDark = Color(0xFFC99400)

// Aliases for compatibility
val BinanceGreen = ImmersiveGreen
val BinanceGreenGlow = ImmersiveGreenLight
val BinanceGreenBg = ImmersiveGreenBg

val BinanceRed = ImmersiveRed
val BinanceRedGlow = ImmersiveRedLight
val BinanceRedBg = ImmersiveRedBg

// Surfaces & Backgrounds
val BgDarkest = ImmersiveBgDarkest
val BgSurface = ImmersiveBgSurface
val BgCard = ImmersiveBgCard
val BgCardElevated = ImmersiveBgElevated
val BgCardSelected = ImmersiveBgSelected

// Borders & Dividers
val BorderSubtle = Color(0xFF333333)
val BorderHighlight = Color(0xFF49454F)

// Typography & Content
val TextPrimary = Color(0xFFE6E1E5)
val TextSecondary = Color(0xFF938F99)
val TextTertiary = Color(0xFF79747E)
val TextMuted = Color(0xFF938F99)
val TextInverse = Color(0xFF1D192B)

// Accents
val AccentCyan = Color(0xFF38BDF8)
val AccentOrange = Color(0xFFFB923C)
val AccentPurple = ImmersivePrimary


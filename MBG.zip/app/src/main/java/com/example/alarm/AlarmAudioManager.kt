package com.example.alarm

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import com.example.data.db.AlertHistoryEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.sin

object AlarmAudioManager {
    private const val TAG = "AlarmAudioManager"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _isAlarmCurrentlyRinging = MutableStateFlow(false)
    val isAlarmCurrentlyRinging: StateFlow<Boolean> = _isAlarmCurrentlyRinging.asStateFlow()

    private val _activeAlertInfo = MutableStateFlow<AlertHistoryEntity?>(null)
    val activeAlertInfo: StateFlow<AlertHistoryEntity?> = _activeAlertInfo.asStateFlow()

    private var mediaPlayer: MediaPlayer? = null
    private var audioTrack: AudioTrack? = null
    private var synthJob: Job? = null
    private var vibrator: Vibrator? = null

    var selectedSoundType: AlarmSoundType = AlarmSoundType.SIREN_LOUD
    var isVibrationEnabled: Boolean = true

    fun triggerAlarm(
        context: Context,
        alertInfo: AlertHistoryEntity,
        soundType: AlarmSoundType = selectedSoundType,
        enableVibration: Boolean = isVibrationEnabled
    ) {
        stopAlarm() // Stop any previous instance first

        _activeAlertInfo.value = alertInfo
        _isAlarmCurrentlyRinging.value = true

        Log.i(TAG, "Triggering ALARM for ${alertInfo.symbol}: ${alertInfo.title}")

        // 1. Start Audio Playback
        startSound(context, soundType)

        // 2. Start Vibration
        if (enableVibration) {
            startVibration(context)
        }
    }

    private fun startSound(context: Context, soundType: AlarmSoundType) {
        when (soundType) {
            AlarmSoundType.SYSTEM_ALARM -> {
                playSystemRingtone(context)
            }
            AlarmSoundType.SIREN_LOUD -> {
                playSynthesizedSiren()
            }
            AlarmSoundType.FAST_PULSE -> {
                playSynthesizedPulse()
            }
            AlarmSoundType.CRYPTO_BELL -> {
                playSynthesizedChime()
            }
        }
    }

    private fun playSystemRingtone(context: Context) {
        try {
            var alarmUri: Uri? = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            if (alarmUri == null) {
                alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            }
            if (alarmUri == null) {
                alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            }

            mediaPlayer = MediaPlayer().apply {
                setDataSource(context, alarmUri!!)
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .setFlags(AudioAttributes.FLAG_AUDIBILITY_ENFORCED)
                        .build()
                )
                isLooping = true
                prepare()
                start()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed system ringtone, falling back to siren", e)
            playSynthesizedSiren()
        }
    }

    private fun playSynthesizedSiren() {
        val sampleRate = 44100
        val minBufferSize = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )

        try {
            audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .setFlags(AudioAttributes.FLAG_AUDIBILITY_ENFORCED)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minBufferSize, 8192))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            audioTrack?.play()

            synthJob = scope.launch {
                val buffer = ShortArray(2048)
                var phase = 0.0
                var time = 0L

                while (isActive && _isAlarmCurrentlyRinging.value) {
                    for (i in buffer.indices) {
                        val t = (time + i) / sampleRate.toDouble()
                        // Sweeping siren between 800 Hz and 1800 Hz
                        val freq = 1100.0 + 600.0 * sin(2.0 * Math.PI * 2.5 * t)
                        phase += 2.0 * Math.PI * freq / sampleRate
                        if (phase > 2.0 * Math.PI) phase -= 2.0 * Math.PI

                        val sample = (sin(phase) * 30000.0).toInt().coerceIn(-32767, 32767)
                        buffer[i] = sample.toShort()
                    }
                    audioTrack?.write(buffer, 0, buffer.size)
                    time += buffer.size
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "AudioTrack Siren failed", e)
        }
    }

    private fun playSynthesizedPulse() {
        val sampleRate = 44100
        val minBufferSize = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )

        try {
            audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minBufferSize, 8192))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            audioTrack?.play()

            synthJob = scope.launch {
                val buffer = ShortArray(2048)
                var phase = 0.0
                var time = 0L

                while (isActive && _isAlarmCurrentlyRinging.value) {
                    for (i in buffer.indices) {
                        val t = (time + i) / sampleRate.toDouble()
                        val cycle = (t * 5.0) % 1.0 // 5 beeps per second
                        val freq = if ((t * 2.5).toInt() % 2 == 0) 1300.0 else 1750.0
                        phase += 2.0 * Math.PI * freq / sampleRate
                        if (phase > 2.0 * Math.PI) phase -= 2.0 * Math.PI

                        val envelope = if (cycle < 0.6) 1.0 else 0.0
                        val sample = (sin(phase) * 28000.0 * envelope).toInt().coerceIn(-32767, 32767)
                        buffer[i] = sample.toShort()
                    }
                    audioTrack?.write(buffer, 0, buffer.size)
                    time += buffer.size
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "AudioTrack Pulse failed", e)
        }
    }

    private fun playSynthesizedChime() {
        val sampleRate = 44100
        val minBufferSize = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )

        try {
            audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minBufferSize, 8192))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            audioTrack?.play()

            synthJob = scope.launch {
                val buffer = ShortArray(2048)
                var phase1 = 0.0
                var phase2 = 0.0
                var time = 0L

                while (isActive && _isAlarmCurrentlyRinging.value) {
                    for (i in buffer.indices) {
                        val t = (time + i) / sampleRate.toDouble()
                        val cycleTime = t % 0.8
                        val decay = Math.exp(-cycleTime * 4.0)

                        phase1 += 2.0 * Math.PI * 987.77 / sampleRate // B5
                        phase2 += 2.0 * Math.PI * 1318.51 / sampleRate // E6
                        if (phase1 > 2.0 * Math.PI) phase1 -= 2.0 * Math.PI
                        if (phase2 > 2.0 * Math.PI) phase2 -= 2.0 * Math.PI

                        val wave = (sin(phase1) + sin(phase2) * 0.7) * 0.5
                        val sample = (wave * decay * 30000.0).toInt().coerceIn(-32767, 32767)
                        buffer[i] = sample.toShort()
                    }
                    audioTrack?.write(buffer, 0, buffer.size)
                    time += buffer.size
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "AudioTrack Chime failed", e)
        }
    }

    private fun startVibration(context: Context) {
        try {
            val timings = longArrayOf(0, 500, 200, 500, 200, 800, 400)
            val amplitudes = intArrayOf(0, 255, 0, 255, 0, 255, 0)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibrator = vibratorManager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val effect = VibrationEffect.createWaveform(timings, amplitudes, 0) // 0 = repeat from start
                vibrator?.vibrate(effect)
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(timings, 0)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Vibration failed", e)
        }
    }

    fun stopAlarm() {
        _isAlarmCurrentlyRinging.value = false
        _activeAlertInfo.value = null

        synthJob?.cancel()
        synthJob = null

        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping mediaPlayer", e)
        }
        mediaPlayer = null

        try {
            audioTrack?.pause()
            audioTrack?.flush()
            audioTrack?.stop()
            audioTrack?.release()
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping audioTrack", e)
        }
        audioTrack = null

        try {
            vibrator?.cancel()
        } catch (e: Exception) {
            Log.e(TAG, "Error canceling vibrator", e)
        }
        vibrator = null

        Log.i(TAG, "ALARM STOPPED successfully")
    }
}

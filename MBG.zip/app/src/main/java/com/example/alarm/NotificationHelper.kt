package com.example.alarm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.db.AlertHistoryEntity

object NotificationHelper {
    const val CHANNEL_ALARM_ID = "binance_price_alarm_channel"
    const val CHANNEL_SERVICE_ID = "binance_monitor_service_channel"
    const val ACTION_STOP_ALARM = "com.example.ACTION_STOP_ALARM"

    const val NOTIFICATION_ID_SERVICE = 1001
    const val NOTIFICATION_ID_ALARM = 2001

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            // Alarm High-Priority Channel
            val alarmChannel = NotificationChannel(
                CHANNEL_ALARM_ID,
                "Alarm Fluktuasi Harga Binance",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Memicu notifikasi dan alarm ponsel saat harga koin bergerak signifikan"
                enableLights(true)
                lightColor = Color.RED
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 200, 500, 200, 800)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                setBypassDnd(true)
            }

            // Foreground Service Channel
            val serviceChannel = NotificationChannel(
                CHANNEL_SERVICE_ID,
                "Layanan Pemantau Real-Time",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Status pemantauan grafik pasar Binance di latar belakang"
                setShowBadge(false)
            }

            notificationManager.createNotificationChannel(alarmChannel)
            notificationManager.createNotificationChannel(serviceChannel)
        }
    }

    fun buildServiceNotification(context: Context, statusText: String = "Memantau pasar Binance secara real-time..."): Notification {
        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(context, CHANNEL_SERVICE_ID)
            .setContentTitle("Binance Price Sentinel Aktif")
            .setContentText(statusText)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    fun showPriceAlarmNotification(context: Context, alert: AlertHistoryEntity) {
        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            context,
            1,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(context, StopAlarmReceiver::class.java).apply {
            action = ACTION_STOP_ALARM
        }
        val stopPendingIntent = PendingIntent.getBroadcast(
            context,
            2,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val changeSign = if (alert.changePercent >= 0) "+" else ""
        val bigText = "${alert.title}\n${alert.message}\nHarga: $${alert.priceTriggered} (${changeSign}${String.format("%.2f", alert.changePercent)}%)"

        val notification = NotificationCompat.Builder(context, CHANNEL_ALARM_ID)
            .setContentTitle("🚨 ALARM BINANCE: ${alert.symbol} ($changeSign${String.format("%.2f", alert.changePercent)}%)")
            .setContentText(alert.message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(bigText))
            .setSmallIcon(android.R.drawable.stat_notify_error)
            .setColor(if (alert.changePercent >= 0) Color.GREEN else Color.RED)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(contentPendingIntent)
            .setAutoCancel(false)
            .setOngoing(true)
            .addAction(
                android.R.drawable.ic_lock_power_off,
                "MATIKAN ALARM",
                stopPendingIntent
            )
            .build()

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID_ALARM, notification)
    }

    fun cancelAlarmNotification(context: Context) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.cancel(NOTIFICATION_ID_ALARM)
    }
}

package com.example.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class StopAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == NotificationHelper.ACTION_STOP_ALARM || intent.action == "com.example.ACTION_STOP_ALARM") {
            Log.d("StopAlarmReceiver", "Received STOP ALARM action")
            AlarmAudioManager.stopAlarm()
            NotificationHelper.cancelAlarmNotification(context)
        }
    }
}

package com.example.alarm

enum class AlarmSoundType(val displayName: String, val description: String) {
    SIREN_LOUD("Sirene Darurat (Loud Siren)", "Nada sirene darurat frekuensi tinggi"),
    SYSTEM_ALARM("Alarm Sistem HP (Default)", "Menggunakan nada dering alarm resmi perangkat"),
    FAST_PULSE("Pulsa Cepat (Rapid Pulse)", "Bunyi 'beep' berulang cepat penanda volatilitas"),
    CRYPTO_BELL("Bel Keras (Chime Bell)", "Dentang bel frekuensi ganda terus-menerus")
}

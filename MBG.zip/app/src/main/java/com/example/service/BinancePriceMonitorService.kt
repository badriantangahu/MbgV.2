package com.example.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.alarm.NotificationHelper
import com.example.data.api.BinanceApiService
import com.example.data.api.BinanceWebSocketClient
import com.example.data.db.AppDatabase
import com.example.data.db.AlertRepository
import com.example.domain.FluctuationEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class BinancePriceMonitorService : Service() {
    private val tag = "BinanceMonitorService"
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private lateinit var webSocketClient: BinanceWebSocketClient
    private lateinit var apiService: BinanceApiService
    private lateinit var repository: AlertRepository
    private lateinit var fluctuationEngine: FluctuationEngine

    private var pollingJob: Job? = null
    private var wsCollectJob: Job? = null

    companion object {
        private val _isServiceRunning = MutableStateFlow(false)
        val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

        var sharedEngine: FluctuationEngine? = null
            private set

        fun start(context: Context) {
            val intent = Intent(context, BinancePriceMonitorService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ContextCompat.startForegroundService(context, intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, BinancePriceMonitorService::class.java)
            context.stopService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        Log.i(tag, "Creating BinancePriceMonitorService...")

        NotificationHelper.createNotificationChannels(this)
        val notification = NotificationHelper.buildServiceNotification(this, "Memantau pasar Binance secara real-time...")
        startForeground(NotificationHelper.NOTIFICATION_ID_SERVICE, notification)

        val database = AppDatabase.getInstance(this)
        repository = AlertRepository(database.alertDao())
        fluctuationEngine = FluctuationEngine(this, repository)
        sharedEngine = fluctuationEngine

        apiService = BinanceApiService()
        webSocketClient = BinanceWebSocketClient()

        _isServiceRunning.value = true

        startMonitoring()
    }

    private fun startMonitoring() {
        // 1. Listen to WebSocket ticker updates
        webSocketClient.connect("BTCUSDT")

        wsCollectJob = serviceScope.launch {
            launch {
                webSocketClient.liveTicker.collect { ticker ->
                    fluctuationEngine.processPriceUpdate(ticker)
                }
            }
            launch {
                webSocketClient.allMiniTickers.collect { tickerList ->
                    for (t in tickerList) {
                        fluctuationEngine.processPriceUpdate(t)
                    }
                }
            }
        }

        // 2. Periodic background refresh polling for all tracked pairs (every 4 seconds) to ensure redundancy
        pollingJob = serviceScope.launch {
            while (isActive) {
                try {
                    val result = apiService.getTopTickers24h()
                    result.onSuccess { tickers ->
                        for (ticker in tickers) {
                            fluctuationEngine.processPriceUpdate(ticker)
                        }
                    }
                } catch (e: Exception) {
                    Log.e(tag, "Polling error", e)
                }
                delay(4000)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onDestroy() {
        Log.i(tag, "Destroying BinancePriceMonitorService...")
        _isServiceRunning.value = false
        pollingJob?.cancel()
        wsCollectJob?.cancel()
        webSocketClient.disconnect()
        serviceScope.launch {
            delay(500)
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
